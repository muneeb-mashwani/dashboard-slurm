"use client";

import { ChangeEvent, useDeferredValue, useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
} from "@/components/ui/pagination";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface JobRow {
  jobKey: string;
  jobId: string;
  userName: string;
  name: string;
  state: string;
  partition: string;
  nodes: string;
  startTime: number;
  endTime: number;
  elapsedSeconds: number;
  allocatedCpus: number;
  gpuCount: number;
  executionCost: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

interface JobDetails {
  jobKey: string;
  jobId: string;
  userName: string;
  flags: string[];
  nodes: string;
  command: string;
  state: string[];
  cpusPerTask: number;
  allocatedCpus: number;
  memoryPerNodeGb: number;
  gresDetail: string[];
  outputPath: string;
  errorPath: string;
  inputPath: string;
  timeLimitMins: number;
  priority: number;
  executionCost: number;
  startTime: number;
  endTime: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

interface JobsDataResponse {
  jobs: JobRow[];
}

interface JobDetailsResponse {
  source: "active" | "completed";
  job: JobDetails;
}

const jsonFetcher = async (url: string) => {
  const response = await fetch(url);
  if (!response.ok) {
    const payload = await response.json().catch(() => ({}));
    throw new Error(typeof payload?.error === "string" ? payload.error : "Failed to fetch jobs data");
  }
  return response.json();
};
const ITEMS_PER_PAGE = 15;
const LOOKBACK_OPTIONS = [1, 3, 6, 24] as const;
type LookbackHours = (typeof LOOKBACK_OPTIONS)[number];

const formatDuration = (seconds: number): string => {
  if (seconds <= 0) return "-";
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours}h ${minutes}m`;
};

const formatTimestamp = (unixSeconds: number): string => {
  if (!unixSeconds || unixSeconds <= 0) return "-";
  return new Date(unixSeconds * 1000).toLocaleString();
};

const formatCurrency = (value: number): string => `$${value.toFixed(3)}`;

const stateBadgeVariant = (state: string): "default" | "secondary" | "destructive" => {
  if (state === "TIMEOUT" || state.startsWith("CANCELLED")) return "destructive";
  return "secondary";
};

const stateBadgeClassName = (state: string): string => {
  if (state === "COMPLETED") return "border-transparent bg-emerald-600 text-white hover:bg-emerald-600";
  if (state === "TIMEOUT") return "border-transparent bg-orange-500 text-white hover:bg-orange-500";
  if (state.startsWith("CANCELLED")) return "border-transparent bg-red-600 text-white hover:bg-red-600";
  return "";
};

const buildDetailsUrl = (job: JobRow | null): string | null => {
  if (!job) return null;

  const params = new URLSearchParams({
    jobKey: job.jobKey,
    userName: job.userName,
    startTime: String(job.startTime),
  });

  if (job.instanceType) {
    params.set("instanceType", job.instanceType);
  }

  return `/api/slurm/job/details/${job.jobId}?${params.toString()}`;
};

const getVisiblePageNumbers = (currentPage: number, totalPages: number): Array<number | "ellipsis-start" | "ellipsis-end"> => {
  if (totalPages <= 7) {
    return Array.from({ length: totalPages }, (_, index) => index + 1);
  }

  if (currentPage <= 4) {
    return [1, 2, 3, 4, 5, "ellipsis-end", totalPages];
  }

  if (currentPage >= totalPages - 3) {
    return [1, "ellipsis-start", totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
  }

  return [1, "ellipsis-start", currentPage - 1, currentPage, currentPage + 1, "ellipsis-end", totalPages];
};

const sortJobs = (jobs: JobRow[]): JobRow[] =>
  [...jobs].sort((a, b) => {
    if (b.startTime !== a.startTime) return b.startTime - a.startTime;
    return Number(b.jobId) - Number(a.jobId);
  });

const mergeJobs = (existingJobs: JobRow[], newJobs: JobRow[]): JobRow[] => {
  const mergedByKey = new Map<string, JobRow>();

  for (const job of existingJobs) {
    mergedByKey.set(job.jobKey, job);
  }

  for (const job of newJobs) {
    mergedByKey.set(job.jobKey, job);
  }

  return sortJobs(Array.from(mergedByKey.values()));
};

export default function JobsDataDashboard() {
  const [jobIdSearch, setJobIdSearch] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const [lookbackHours, setLookbackHours] = useState<LookbackHours>(1);
  const [cachedJobs, setCachedJobs] = useState<JobRow[]>([]);
  const [maxFetchedHours, setMaxFetchedHours] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedJob, setSelectedJob] = useState<JobRow | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const deferredJobIdSearch = useDeferredValue(jobIdSearch);
  const deferredUserSearch = useDeferredValue(userSearch);

  const fetchJobWindow = async (hours: number, excludeRecentHours = 0): Promise<JobRow[]> => {
    const params = new URLSearchParams({
      page: "1",
      pageSize: "200000",
      lookbackHours: String(hours),
      excludeRecentHours: String(excludeRecentHours),
    });

    const payload = await jsonFetcher(`/api/slurm/jobs/executed?${params.toString()}`) as JobsDataResponse;
    return payload.jobs || [];
  };

  const { data: detailsData, isLoading: detailsLoading } = useSWR<JobDetailsResponse>(
    isModalOpen ? buildDetailsUrl(selectedJob) : null,
    jsonFetcher
  );

  useEffect(() => {
    let cancelled = false;

    const fetchInitialWindow = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const jobs = await fetchJobWindow(lookbackHours, 0);
        if (!cancelled) {
          setCachedJobs(sortJobs(jobs));
          setMaxFetchedHours(lookbackHours);
        }
      } catch {
        if (!cancelled) {
          setError("Failed to load jobs data from Slurm.");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    fetchInitialWindow();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    const fetchMissingWindow = async () => {
      if (lookbackHours <= maxFetchedHours || maxFetchedHours === 0) {
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        const deltaHours = lookbackHours - maxFetchedHours;
        const additionalJobs = await fetchJobWindow(deltaHours, maxFetchedHours);
        if (!cancelled) {
          setCachedJobs((currentJobs) => mergeJobs(currentJobs, additionalJobs));
          setMaxFetchedHours(lookbackHours);
        }
      } catch {
        if (!cancelled) {
          setError("Failed to load jobs data from Slurm.");
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    fetchMissingWindow();

    return () => {
      cancelled = true;
    };
  }, [lookbackHours, maxFetchedHours]);

  useEffect(() => {
    const refreshInterval = setInterval(async () => {
      try {
        const jobs = await fetchJobWindow(lookbackHours, 0);
        setCachedJobs(sortJobs(jobs));
        setMaxFetchedHours(lookbackHours);
        setError(null);
      } catch {
        setError("Failed to load jobs data from Slurm.");
      }
    }, 300000);

    return () => {
      clearInterval(refreshInterval);
    };
  }, [lookbackHours]);

  useEffect(() => {
    setCurrentPage(1);
  }, [deferredJobIdSearch, deferredUserSearch, lookbackHours]);

  const jobsInSelectedWindow = useMemo(() => {
    const cutoffEpoch = Math.floor(Date.now() / 1000) - lookbackHours * 60 * 60;
    return cachedJobs.filter((job) => job.startTime >= cutoffEpoch);
  }, [cachedJobs, lookbackHours]);

  const filteredJobs = useMemo(() => {
    const normalizedJobId = deferredJobIdSearch.trim().toLowerCase();
    const normalizedUser = deferredUserSearch.trim().toLowerCase();

    return jobsInSelectedWindow.filter((job: JobRow) => {
      const jobIdMatches = normalizedJobId ? job.jobId.toLowerCase().includes(normalizedJobId) : true;
      const userMatches = normalizedUser ? job.userName.toLowerCase().includes(normalizedUser) : true;
      return jobIdMatches && userMatches;
    });
  }, [jobsInSelectedWindow, deferredJobIdSearch, deferredUserSearch]);

  const totalPages = Math.max(1, Math.ceil(filteredJobs.length / ITEMS_PER_PAGE));
  const safeCurrentPage = Math.min(currentPage, totalPages);

  const paginatedJobs = useMemo(() => {
    const startIndex = (safeCurrentPage - 1) * ITEMS_PER_PAGE;
    return filteredJobs.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredJobs, safeCurrentPage]);

  useEffect(() => {
    if (currentPage !== safeCurrentPage) {
      setCurrentPage(safeCurrentPage);
    }
  }, [currentPage, safeCurrentPage]);

  const selectedJobDetails = detailsData?.job;
  const displayExecutionCost = typeof selectedJob?.executionCost === "number"
    ? selectedJob.executionCost
    : (selectedJobDetails?.executionCost || 0);
  const resolvedInstanceHourlyRate = typeof selectedJobDetails?.instanceHourlyRate === "number"
    ? formatCurrency(selectedJobDetails.instanceHourlyRate)
    : typeof selectedJob?.instanceHourlyRate === "number"
      ? formatCurrency(selectedJob.instanceHourlyRate)
      : "Not configured";

  const openJobModal = (job: JobRow) => {
    setSelectedJob(job);
    setIsModalOpen(true);
  };

  const closeJobModal = (open: boolean) => {
    setIsModalOpen(open);
    if (!open) {
      setSelectedJob(null);
    }
  };

  const pageNumbers = getVisiblePageNumbers(safeCurrentPage, totalPages);

  return (
    <>
      <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
            <div>
              <CardTitle>Jobs Data</CardTitle>
              <CardDescription>
                Browse completed, cancelled, and timeout jobs with detailed execution metadata and estimated cost.
              </CardDescription>
            </div>
            <div className="w-full md:w-56 md:shrink-0">
              <p className="mb-1 text-xs font-medium text-muted-foreground md:text-right">Time Range</p>
              <Select
                value={String(lookbackHours)}
                onValueChange={(value: string) => setLookbackHours(Number(value) as LookbackHours)}
              >
                <SelectTrigger className="w-full md:ml-auto">
                  <SelectValue placeholder="Select range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Last 1 Hour</SelectItem>
                  <SelectItem value="3">Last 3 Hours</SelectItem>
                  <SelectItem value="6">Last 6 Hours</SelectItem>
                  <SelectItem value="24">Last 24 Hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={jobIdSearch}
                onChange={(event: ChangeEvent<HTMLInputElement>) => setJobIdSearch(event.target.value)}
                placeholder="Search by job ID"
                className="pl-9"
              />
            </div>
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={userSearch}
                onChange={(event: ChangeEvent<HTMLInputElement>) => setUserSearch(event.target.value)}
                placeholder="Search by username"
                className="pl-9"
              />
            </div>
          </div>

          {error && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
              {error}
            </div>
          )}

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job ID</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>State</TableHead>
                  <TableHead>Partition</TableHead>
                  <TableHead>Instance</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && (
                  <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                      Loading jobs...
                    </TableCell>
                  </TableRow>
                )}

                {!isLoading && filteredJobs.length === 0 && (
                  <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                      No jobs found for the current filters.
                    </TableCell>
                  </TableRow>
                )}

                {!isLoading &&
                  paginatedJobs.map((job: JobRow) => (
                    <TableRow
                      key={job.jobKey}
                      onClick={() => {
                        openJobModal(job);
                      }}
                      className="cursor-pointer"
                      data-state={selectedJob?.jobKey === job.jobKey ? "selected" : undefined}
                    >
                      <TableCell className="font-mono">{job.jobId}</TableCell>
                      <TableCell>{job.userName}</TableCell>
                      <TableCell>
                        <Badge variant={stateBadgeVariant(job.state)} className={stateBadgeClassName(job.state)}>{job.state}</Badge>
                      </TableCell>
                      <TableCell>{job.partition}</TableCell>
                      <TableCell className="font-mono">{job.instanceType || "-"}</TableCell>
                      <TableCell>{formatTimestamp(job.startTime)}</TableCell>
                      <TableCell>{formatDuration(job.elapsedSeconds)}</TableCell>
                      <TableCell className="font-medium">{formatCurrency(job.executionCost)}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>

            {!isLoading && filteredJobs.length > 0 && (
              <div className="flex flex-col gap-3 pt-2 md:flex-row md:items-center md:justify-between">
                <p className="text-sm text-muted-foreground">
                  Showing {(safeCurrentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(safeCurrentPage * ITEMS_PER_PAGE, filteredJobs.length)} of {filteredJobs.length} jobs
                </p>
                <Pagination className="mx-0 w-auto justify-start md:justify-end">
                  <PaginationContent>
                    <PaginationItem>
                      <Button
                        variant="outline"
                        size="sm"
                        type="button"
                        onClick={() => setCurrentPage((page: number) => Math.max(1, page - 1))}
                        disabled={safeCurrentPage === 1}
                      >
                        Prev
                      </Button>
                    </PaginationItem>

                    {pageNumbers.map((pageNumber) => {
                      if (pageNumber === "ellipsis-start" || pageNumber === "ellipsis-end") {
                        return (
                          <PaginationItem key={pageNumber}>
                            <PaginationEllipsis />
                          </PaginationItem>
                        );
                      }

                      return (
                        <PaginationItem key={pageNumber}>
                          <Button
                            type="button"
                            variant={pageNumber === safeCurrentPage ? "secondary" : "ghost"}
                            size="sm"
                            onClick={() => setCurrentPage(pageNumber)}
                          >
                            {pageNumber}
                          </Button>
                        </PaginationItem>
                      );
                    })}

                    <PaginationItem>
                      <Button
                        variant="outline"
                        size="sm"
                        type="button"
                        onClick={() => setCurrentPage((page: number) => Math.min(totalPages, page + 1))}
                        disabled={safeCurrentPage === totalPages}
                      >
                        Next
                      </Button>
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
        </CardContent>
      </Card>
        </div>

        <Dialog open={isModalOpen} onOpenChange={closeJobModal}>
          <DialogContent aria-describedby={undefined} className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <span>Job Details</span>
                {selectedJob && <span className="font-mono text-base">#{selectedJob.jobId}</span>}
              </DialogTitle>
              <DialogDescription>
                Terminal job metadata and cost breakdown for the selected job record.
              </DialogDescription>
            </DialogHeader>

            {selectedJob && detailsLoading && (
              <p className="text-sm text-muted-foreground">Loading job details...</p>
            )}

            {selectedJob && !detailsLoading && !selectedJobDetails && (
              <p className="text-sm text-destructive">Unable to load the selected job details.</p>
            )}

            {selectedJob && !detailsLoading && selectedJobDetails && (
              <div className="grid grid-cols-1 gap-3 text-sm md:grid-cols-2">
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Job ID</div>
                  <div className="font-mono font-medium">{selectedJobDetails.jobId}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">User</div>
                  <div className="font-medium">{selectedJobDetails.userName}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Nodes</div>
                  <div className="font-medium">{selectedJobDetails.nodes || "-"}</div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Instance Type</div>
                  <div className="font-mono">{selectedJobDetails.instanceType || selectedJob?.instanceType || "-"}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Instance Hourly Rate</div>
                  <div className="font-medium">
                    {resolvedInstanceHourlyRate}
                  </div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Start Time</div>
                  <div className="font-medium">{formatTimestamp(selectedJobDetails.startTime)}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">End Time</div>
                  <div className="font-medium">{formatTimestamp(selectedJobDetails.endTime)}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Command</div>
                  <div className="font-mono break-all">{selectedJobDetails.command || "-"}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">State</div>
                  <div className="font-medium">{selectedJobDetails.state.join(", ")}</div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">CPUs Per Task</div>
                  <div className="font-medium">{selectedJobDetails.cpusPerTask || selectedJobDetails.allocatedCpus || "-"}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Memory per Node (GB)</div>
                  <div className="font-medium">{selectedJobDetails.memoryPerNodeGb ? selectedJobDetails.memoryPerNodeGb.toFixed(2) : "-"}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Gres Detail</div>
                  <div className="font-medium">{selectedJobDetails.gresDetail?.length ? selectedJobDetails.gresDetail.join(", ") : "-"}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Output Path</div>
                  <div className="font-mono break-all">{selectedJobDetails.outputPath || "-"}</div>
                </div>
                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Error Path</div>
                  <div className="font-mono break-all">{selectedJobDetails.errorPath || "-"}</div>
                </div>
                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Input Path</div>
                  <div className="font-mono break-all">{selectedJobDetails.inputPath || "-"}</div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Time Limit (mins)</div>
                  <div className="font-medium">{selectedJobDetails.timeLimitMins || "-"}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Priority</div>
                  <div className="font-medium">{selectedJobDetails.priority || "-"}</div>
                </div>

                <div className="rounded-md border bg-muted/40 p-3 md:col-span-2">
                  <div className="text-muted-foreground">Cost of execution</div>
                  <div className="text-lg font-semibold">{formatCurrency(displayExecutionCost)}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Flags Used</div>
                  <div className="font-medium break-words">
                    {selectedJobDetails.flags?.length ? selectedJobDetails.flags.join(", ") : "-"}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </>
  );
}
