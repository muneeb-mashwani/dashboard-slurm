export const dynamic = 'force-dynamic';

import { NextResponse } from "next/server";
import { fetchSlurmData } from "@/lib/slurm-api";

const getEnv = (): Record<string, string | undefined> => {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  if (env) {
    return env;
  }
  return {};
};

export async function GET(req: Request) {
  const env = getEnv();
  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") || "50000"), 1), 200000);
  const lookbackDays = Math.max(
    1,
    Number(url.searchParams.get("lookbackDays") || env.JOBS_DATA_LOOKBACK_DAYS || "3650")
  );
  const startTimeEpoch = Math.floor(Date.now() / 1000) - lookbackDays * 24 * 60 * 60;

  const endpoints = [
    `/jobs?start_time=${startTimeEpoch}`,
    "/jobs",
  ];

  let selectedData: any = undefined;
  let selectedType: "slurmdb" | "slurm" | null = null;
  let selectedEndpoint: string | null = null;
  let selectedJobsCount = -1;
  let error: string | undefined = undefined;
  let status: number | undefined = undefined;

  for (const endpoint of endpoints) {
    const response = await fetchSlurmData(endpoint, { type: "slurmdb" });
    if (response.error) {
      error = response.error;
      status = response.status;
      continue;
    }

    const jobsCount = Array.isArray(response.data?.jobs) ? response.data.jobs.length : 0;
    if (jobsCount > selectedJobsCount) {
      selectedData = response.data;
      selectedType = "slurmdb";
      selectedEndpoint = endpoint;
      selectedJobsCount = jobsCount;
    }
    error = undefined;
    status = undefined;
  }

  if (!selectedData) {
    const slurmResponse = await fetchSlurmData('/jobs', { type: 'slurm' });
    if (slurmResponse.error) {
      return NextResponse.json({ error: slurmResponse.error || error }, { status: slurmResponse.status || status });
    }

    selectedData = slurmResponse.data;
    selectedType = 'slurm';
    selectedEndpoint = '/jobs';
    selectedJobsCount = Array.isArray(slurmResponse.data?.jobs) ? slurmResponse.data.jobs.length : 0;
  }

  const jobs = Array.isArray(selectedData?.jobs) ? selectedData.jobs.slice(0, limit) : [];
  const existingMeta = selectedData?.meta && typeof selectedData.meta === "object" ? selectedData.meta : undefined;

  return NextResponse.json({
    ...selectedData,
    jobs,
    meta: {
      ...existingMeta,
      count: jobs.length,
      limit,
      lookbackDays,
      selectedType,
      selectedEndpoint,
      selectedJobsCount,
    },
  });
}