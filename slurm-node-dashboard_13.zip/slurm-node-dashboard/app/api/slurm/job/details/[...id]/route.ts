export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { fetchSlurmData } from "@/lib/slurm-api";
import { calculateExecutionCost } from "@/lib/job-cost";

const getEnv = (): Record<string, string | undefined> => {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  if (env) {
    return env;
  }
  return {};
};

const isAlphaNumeric = (char: string): boolean => {
  const lower = char.toLowerCase();
  return (lower >= "a" && lower <= "z") || (char >= "0" && char <= "9");
};

const isValidInstanceTypeEnvKey = (key: string): boolean => {
  const normalized = key.toLowerCase().trim();
  const dotIndex = normalized.indexOf(".");
  if (dotIndex <= 0 || dotIndex >= normalized.length - 1) return false;

  const family = normalized.slice(0, dotIndex);
  const size = normalized.slice(dotIndex + 1);
  if (!(family[0] >= "a" && family[0] <= "z")) return false;

  let familyHasDigit = false;
  for (const char of family) {
    if (char >= "0" && char <= "9") {
      familyHasDigit = true;
      continue;
    }
    if ((char >= "a" && char <= "z") || char === "-") continue;
    return false;
  }

  if (!familyHasDigit) return false;

  for (const char of size) {
    if (!isAlphaNumeric(char)) return false;
  }

  return size.length > 0;
};

const getConfiguredInstanceTypes = (env: Record<string, string | undefined>): string[] => {
  const instanceTypes: string[] = [];

  for (const [key, value] of Object.entries(env)) {
    if (!isValidInstanceTypeEnvKey(key)) continue;

    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric < 0) continue;
    instanceTypes.push(key.toLowerCase());
  }

  return Array.from(new Set(instanceTypes));
};

const selectCpuDefault = (configured: string[]): string | null => {
  const preferred = ["m5.xlarge", "c5.2xlarge", "r5.2xlarge"];
  for (const candidate of preferred) {
    if (configured.includes(candidate)) return candidate;
  }

  const nonGpu = configured.find((type) => !type.startsWith("g"));
  return nonGpu || null;
};

const selectGpuDefault = (configured: string[]): string | null => {
  if (configured.includes("g5.xlarge")) return "g5.xlarge";
  const gpu = configured.find((type) => type.startsWith("g"));
  return gpu || null;
};

const inferInstanceTypeFromHints = (
  partition: string | undefined,
  nodes: string | undefined,
  configured: string[]
): string | null => {
  if (configured.length === 0) return null;

  const hints = `${partition || ""} ${nodes || ""}`.toLowerCase();
  if (hints.includes("gpu")) {
    return selectGpuDefault(configured);
  }

  if (hints.includes("cpu")) {
    return selectCpuDefault(configured);
  }

  return null;
};

interface NumericField {
  number?: number;
}

interface SlurmTresEntry {
  type?: string;
  name?: string;
  count?: number;
}

interface JobRecord {
  job_id?: string | number;
  user?: string;
  partition?: string;
  user_name?: string;
  flags?: string[];
  comment?: string;
  admin_comment?: string;
  system_comment?: string;
  extra?: string;
  nodes?: string;
  command?: string;
  submit_line?: string;
  job_state?: string | string[];
  state?: { current?: string[]; reason?: string };
  cpus_per_task?: NumericField;
  cpus?: NumericField;
  required?: {
    CPUs?: number;
    memory_per_node?: NumericField;
  };
  memory_per_node?: NumericField;
  gres_detail?: string[];
  tres_req_str?: string;
  standard_output?: string;
  standard_error?: string;
  standard_input?: string;
  time_limit?: NumericField;
  priority?: NumericField;
  time?: {
    start?: number;
    end?: number;
    elapsed?: number;
    limit?: { number?: number };
  };
  start_time?: NumericField;
  end_time?: NumericField;
  tres?: {
    allocated?: SlurmTresEntry[];
    requested?: SlurmTresEntry[];
  };
}

const readStringField = (value: unknown): string | null => {
  if (typeof value === "string") {
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }

  if (value && typeof value === "object") {
    const candidate = value as { string?: unknown; value?: unknown };
    if (typeof candidate.string === "string") {
      const normalized = candidate.string.trim();
      return normalized.length > 0 ? normalized : null;
    }
    if (typeof candidate.value === "string") {
      const normalized = candidate.value.trim();
      return normalized.length > 0 ? normalized : null;
    }
  }

  return null;
};

const extractInstanceTypeFromComment = (...candidates: unknown[]): string | null => {
  for (const candidate of candidates) {
    const text = readStringField(candidate);
    if (!text) continue;

    const match = /ec2instancetype\s*=\s*([a-z0-9.-]+)/i.exec(text);
    if (!match?.[1]) continue;

    const value = match[1].trim().replace(/^['"]|['"]$/g, "");
    if (value) return value.toLowerCase();
  }

  return null;
};

const toNumber = (value: unknown, fallback = 0): number => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  return fallback;
};

const parseGpuCountFromText = (text?: string): number => {
  if (!text) return 0;
  const matches = text.match(/gpu(?::[^:,]+)?:(\d+)/gi);
  if (!matches) return 0;

  return matches.reduce((sum, token) => {
    const parts = token.split(":");
    const count = Number(parts.at(-1));
    return sum + (Number.isFinite(count) ? count : 0);
  }, 0);
};

const extractState = (job: JobRecord): string[] => {
  if (Array.isArray(job.job_state)) return job.job_state;
  if (typeof job.job_state === "string") return [job.job_state];
  if (job.state?.current?.length) return job.state.current;
  return ["UNKNOWN"];
};

const getElapsedSeconds = (job: JobRecord): number => {
  if (typeof job.time?.elapsed === "number") return Math.max(0, job.time.elapsed);

  const start = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
  const end = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
  if (!start) return 0;

  const effectiveEnd = end > 0 ? end : Math.floor(Date.now() / 1000);
  return Math.max(0, effectiveEnd - start);
};

const getCpus = (job: JobRecord): number => {
  const fromTres = job.tres?.allocated?.find((entry) => entry.type?.toLowerCase() === "cpu")?.count;
  if (typeof fromTres === "number") return Math.max(0, fromTres);

  return Math.max(
    0,
    toNumber(job.required?.CPUs, 0) || toNumber(job.cpus_per_task?.number, 0) || toNumber(job.cpus?.number, 0)
  );
};

const getGpuCount = (job: JobRecord): number => {
  const tresGpu = (job.tres?.allocated || [])
    .filter((entry) => entry.type?.toLowerCase() === "gres" && entry.name?.toLowerCase().includes("gpu"))
    .reduce((sum, entry) => sum + toNumber(entry.count, 0), 0);

  if (tresGpu > 0) return tresGpu;

  const detail = Array.isArray(job.gres_detail) ? job.gres_detail.join(",") : "";
  const detailGpu = parseGpuCountFromText(detail);
  if (detailGpu > 0) return detailGpu;

  return parseGpuCountFromText(job.tres_req_str);
};

const toGb = (memoryValue: number): number => {
  if (memoryValue <= 0) return 0;
  return memoryValue / 1024;
};

const buildJobKey = (jobId: string, userName: string, startTime: number, state: string): string =>
  [jobId, userName, startTime, state].join("::");

const normalizeJobDetails = (
  job: JobRecord,
  fallbackInstanceType: string | null,
  configuredInstanceTypes: string[]
) => {
  const state = extractState(job);
  const primaryState = state[0] || "UNKNOWN";
  const elapsedSeconds = getElapsedSeconds(job);
  const allocatedCpus = getCpus(job);
  const gpuCount = getGpuCount(job);
  const startTime = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
  const endTime = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));

  const memoryPerNode = toNumber(job.memory_per_node?.number, toNumber(job.required?.memory_per_node?.number, 0));
  const timeLimitMinutes = toNumber(job.time_limit?.number, toNumber(job.time?.limit?.number, 0));
  const priority = toNumber(job.priority?.number, 0);
  const instanceTypeFromComment = extractInstanceTypeFromComment(
    job.comment,
    job.admin_comment,
    job.system_comment,
    job.extra
  );
  const inferredInstanceType = inferInstanceTypeFromHints(job.partition, job.nodes, configuredInstanceTypes);
  const normalizedFallbackInstanceType =
    typeof fallbackInstanceType === "string" && fallbackInstanceType.trim().length > 0
      ? fallbackInstanceType.trim().toLowerCase()
      : null;

  const cost = calculateExecutionCost({
    elapsedSeconds,
    allocatedCpus,
    gpuCount,
    nodes: job.nodes,
    instanceTypeOverride: instanceTypeFromComment ?? normalizedFallbackInstanceType ?? inferredInstanceType ?? undefined,
    startTime,
    endTime,
  });

  const requestedGres = (job.tres?.requested || [])
    .filter((entry) => entry.type?.toLowerCase() === "gres")
    .map((entry) => `${entry.name || "gres"}:${toNumber(entry.count, 0)}`);

  return {
    jobId: String(job.job_id ?? ""),
    userName: job.user_name || job.user || "unknown",
    jobKey: buildJobKey(String(job.job_id ?? ""), job.user_name || job.user || "unknown", startTime, primaryState),
    nodes: job.nodes || "-",
    command: job.command || job.submit_line || "-",
    state,
    cpusPerTask: toNumber(job.cpus_per_task?.number, 0),
    allocatedCpus,
    memoryPerNodeGb: toGb(memoryPerNode),
    gresDetail: Array.isArray(job.gres_detail) && job.gres_detail.length > 0 ? job.gres_detail : requestedGres,
    outputPath: job.standard_output || "-",
    errorPath: job.standard_error || "-",
    inputPath: job.standard_input || "/dev/null",
    timeLimitMins: timeLimitMinutes,
    priority,
    elapsedSeconds,
    executionCost: cost.totalCost,
    startTime,
    endTime,
    instanceType: cost.instanceType,
    instanceHourlyRate: cost.instanceHourlyRate,
    flags: Array.isArray(job.flags)
      ? job.flags.filter((flag): flag is string => typeof flag === "string" && flag.trim().length > 0)
      : [],
  };
};

const matchJobRecord = (
  job: JobRecord,
  requestedJobId: string,
  requestedJobKey: string | null,
  requestedUserName: string | null,
  requestedStartTime: number | null
) => {
  const state = extractState(job);
  const primaryState = state[0] || "UNKNOWN";
  const jobId = String(job.job_id ?? "");
  const userName = job.user_name || job.user || "unknown";
  const startTime = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));

  if (jobId !== requestedJobId) {
    return false;
  }

  if (requestedJobKey) {
    return buildJobKey(jobId, userName, startTime, primaryState) === requestedJobKey;
  }

  if (requestedUserName && userName !== requestedUserName) {
    return false;
  }

  if (requestedStartTime !== null && startTime !== requestedStartTime) {
    return false;
  }

  return true;
};

const fetchJobsWithStateFallback = async (
  type: "slurm" | "slurmdb",
  requestedJobId: string,
  requestedJobKey: string | null,
  requestedUserName: string | null,
  requestedStartTime: number | null,
  lookupStartEpoch: number
): Promise<{
  matchedJob: JobRecord | null;
  jobs: JobRecord[];
  error?: string;
  status?: number;
}> => {
  const endpoints = [
    `/jobs?state=completed,cancelled,timeout&start_time=${lookupStartEpoch}`,
    `/jobs?state=completed,cancelled,timeout`,
    `/jobs?start_time=${lookupStartEpoch}`,
    `/jobs`,
  ];

  let largestJobsSet: JobRecord[] = [];
  let lastError: string | undefined = undefined;
  let lastStatus: number | undefined = undefined;

  for (const endpoint of endpoints) {
    const response = await fetchSlurmData(endpoint, {
      type,
      revalidate: 0,
    });

    if (response.error) {
      lastError = response.error;
      lastStatus = response.status;
      continue;
    }

    const jobs = Array.isArray(response.data?.jobs) ? (response.data.jobs as JobRecord[]) : [];
    if (jobs.length > largestJobsSet.length) {
      largestJobsSet = jobs;
    }

    const matchedJob = jobs.find((job) =>
      matchJobRecord(
        job,
        requestedJobId,
        requestedJobKey,
        requestedUserName,
        Number.isFinite(requestedStartTime) ? requestedStartTime : null
      )
    ) || jobs.find((job) => String(job.job_id ?? "") === requestedJobId);

    if (matchedJob) {
      return { matchedJob, jobs, error: undefined, status: undefined };
    }

    lastError = undefined;
    lastStatus = undefined;
  }

  return {
    matchedJob: null,
    jobs: largestJobsSet,
    error: lastError,
    status: lastStatus,
  };
};

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string[] }> }
) {
  const env = getEnv();
  const configuredInstanceTypes = getConfiguredInstanceTypes(env);
  const url = new URL(req.url);
  const { id } = await params;
  const jobId = id[0];
  const requestedJobKey = url.searchParams.get("jobKey");
  const requestedUserName = url.searchParams.get("userName");
  const requestedStartTimeRaw = url.searchParams.get("startTime");
  const requestedInstanceType = url.searchParams.get("instanceType");
  const requestedStartTime = requestedStartTimeRaw ? Number(requestedStartTimeRaw) : null;
  const defaultLookbackDays = 7;
  const lookupStartEpoch = Number.isFinite(requestedStartTime) && (requestedStartTime as number) > 0
    ? Math.max(0, (requestedStartTime as number) - defaultLookbackDays * 24 * 60 * 60)
    : Math.floor(Date.now() / 1000) - defaultLookbackDays * 24 * 60 * 60;

  const slurmdbLookup = await fetchJobsWithStateFallback(
    "slurmdb",
    jobId,
    requestedJobKey,
    requestedUserName,
    requestedStartTime,
    lookupStartEpoch
  );

  let matchedJob = slurmdbLookup.matchedJob;
  let source: "completed" | "active" = "completed";

  let slurmLookup:
    | {
        matchedJob: JobRecord | null;
        jobs: JobRecord[];
        error?: string;
        status?: number;
      }
    | null = null;

  if (!matchedJob) {
    slurmLookup = await fetchJobsWithStateFallback(
      "slurm",
      jobId,
      requestedJobKey,
      requestedUserName,
      requestedStartTime,
      lookupStartEpoch
    );

    if (slurmLookup.matchedJob) {
      matchedJob = slurmLookup.matchedJob;
      source = "active";
    }
  }

  if (!matchedJob) {
    const status = slurmdbLookup.status || slurmLookup?.status || 404;
    return NextResponse.json({ error: "Job not found" }, { status });
  }

  let fallbackInstanceType = requestedInstanceType;

  if (!fallbackInstanceType) {
    if (!slurmLookup) {
      slurmLookup = await fetchJobsWithStateFallback(
        "slurm",
        jobId,
        requestedJobKey,
        requestedUserName,
        requestedStartTime,
        lookupStartEpoch
      );
    }

    const matchedSlurmJob = slurmLookup.matchedJob;
    if (matchedSlurmJob) {
      fallbackInstanceType = extractInstanceTypeFromComment(
        matchedSlurmJob.comment,
        matchedSlurmJob.admin_comment,
        matchedSlurmJob.system_comment,
        matchedSlurmJob.extra
      );
    }
  }

  return NextResponse.json({
    source,
    job: normalizeJobDetails(matchedJob, fallbackInstanceType, configuredInstanceTypes),
  });
}
