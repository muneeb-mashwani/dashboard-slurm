export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { fetchSlurmData } from "@/lib/slurm-api";
import { calculateExecutionCost } from "@/lib/job-cost";

interface NumericField {
  number?: number;
}

interface SlurmTresEntry {
  type?: string;
  name?: string;
  count?: number;
}

interface SlurmJobRecord {
  job_id?: string | number;
  user?: string;
  user_name?: string;
  name?: string;
  job_state?: string | string[];
  state?: { current?: string[]; reason?: string };
  partition?: string;
  nodes?: string;
  time?: {
    start?: number;
    end?: number;
    elapsed?: number;
    limit?: { number?: number };
  };
  start_time?: NumericField;
  end_time?: NumericField;
  submit_time?: NumericField;
  cpus_per_task?: NumericField;
  cpus?: NumericField;
  required?: {
    CPUs?: number;
    memory_per_node?: NumericField;
  };
  tres?: {
    allocated?: SlurmTresEntry[];
    requested?: SlurmTresEntry[];
  };
  tres_req_str?: string;
  gres_detail?: string[];
}

const toNumber = (value: unknown, fallback = 0): number => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  return fallback;
};

const parseGpuCountFromText = (text?: string): number => {
  if (!text) return 0;
  const matches = text.match(/gpu(?::[^:,]+)?:(\d+)/gi);
  if (!matches) return 0;

  return matches.reduce((sum, token) => {
    const parts = token.split(":");
    const count = Number(parts.at(-1));
    return sum + (Number.isFinite(count) ? count : 0);
  }, 0);
};

const getPrimaryState = (job: SlurmJobRecord): string => {
  if (Array.isArray(job.job_state) && job.job_state.length > 0) return job.job_state[0];
  if (typeof job.job_state === "string") return job.job_state;
  if (job.state?.current?.length) return job.state.current[0];
  return "UNKNOWN";
};

const isExecutedOrCancelled = (state: string): boolean => {
  const normalized = state.toUpperCase();
  return normalized === "COMPLETED" || normalized.startsWith("CANCELLED");
};

const getElapsedSeconds = (job: SlurmJobRecord): number => {
  if (typeof job.time?.elapsed === "number") return Math.max(0, job.time.elapsed);

  const start = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
  const end = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
  if (!start) return 0;

  const effectiveEnd = end > 0 ? end : Math.floor(Date.now() / 1000);
  return Math.max(0, effectiveEnd - start);
};

const getAllocatedCpus = (job: SlurmJobRecord): number => {
  const fromTres = job.tres?.allocated?.find((item) => item.type?.toLowerCase() === "cpu")?.count;
  if (typeof fromTres === "number") return Math.max(0, fromTres);

  return Math.max(
    0,
    toNumber(job.required?.CPUs, 0) || toNumber(job.cpus_per_task?.number, 0) || toNumber(job.cpus?.number, 0)
  );
};

const getGpuCount = (job: SlurmJobRecord): number => {
  const tresGpu = (job.tres?.allocated || [])
    .filter((item) => item.type?.toLowerCase() === "gres" && item.name?.toLowerCase().includes("gpu"))
    .reduce((sum, item) => sum + toNumber(item.count, 0), 0);

  if (tresGpu > 0) return tresGpu;

  const gresDetail = Array.isArray(job.gres_detail) ? job.gres_detail.join(",") : "";
  const fromDetail = parseGpuCountFromText(gresDetail);
  if (fromDetail > 0) return fromDetail;

  return parseGpuCountFromText(job.tres_req_str);
};

const buildJobKey = (jobId: string, userName: string, startTime: number, state: string): string =>
  [jobId, userName, startTime, state].join("::");

export async function GET(req: Request) {
  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") || "500"), 1), 2000);

  const { data, error, status } = await fetchSlurmData("/jobs", { type: "slurmdb" });

  if (error) {
    return NextResponse.json({ error }, { status });
  }

  const jobs = Array.isArray(data?.jobs) ? (data.jobs as SlurmJobRecord[]) : [];

  const normalizedJobs = jobs
    .map((job) => {
      const jobId = String(job.job_id ?? "").trim();
      if (!jobId) return null;

      const state = getPrimaryState(job);
      if (!isExecutedOrCancelled(state)) return null;

      const startTime = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
      const endTime = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
      const elapsedSeconds = getElapsedSeconds(job);
      const allocatedCpus = getAllocatedCpus(job);
      const gpuCount = getGpuCount(job);
      const cost = calculateExecutionCost({
        elapsedSeconds,
        allocatedCpus,
        gpuCount,
        nodes: job.nodes,
        startTime,
        endTime,
      });

      return {
        jobId,
        userName: job.user_name || job.user || "unknown",
        name: job.name || "Unnamed Job",
        state,
        partition: job.partition || "-",
        nodes: job.nodes || "-",
        startTime,
        endTime,
        elapsedSeconds,
        allocatedCpus,
        gpuCount,
        executionCost: cost.totalCost,
        instanceType: cost.instanceType,
        instanceHourlyRate: cost.instanceHourlyRate,
        jobKey: buildJobKey(jobId, job.user_name || job.user || "unknown", startTime, state),
      };
    })
    .filter((job): job is NonNullable<typeof job> => Boolean(job))
    .sort((a, b) => {
      if (b.startTime !== a.startTime) return b.startTime - a.startTime;
      return Number(b.jobId) - Number(a.jobId);
    })
    .slice(0, limit);

  return NextResponse.json({
    jobs: normalizedJobs,
    meta: {
      count: normalizedJobs.length,
      limit,
      cpuCostPerCoreHour: Number(process.env.JOB_CPU_COST_PER_CORE_HOUR ?? process.env.NEXT_PUBLIC_JOB_CPU_COST_PER_CORE_HOUR ?? 0.02),
      gpuCostPerHour: Number(process.env.JOB_GPU_COST_PER_HOUR ?? process.env.NEXT_PUBLIC_JOB_GPU_COST_PER_HOUR ?? 0.5),
    },
  });
}
