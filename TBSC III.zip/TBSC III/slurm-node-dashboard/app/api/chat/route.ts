import { createOpenAI } from "@ai-sdk/openai";
import { streamText, convertToModelMessages, stepCountIs } from "ai";
import { loadLLMConfig, buildToolsAndPrompt } from "@/lib/llm-config";

const env = process.env;

export const maxDuration = 30;

export async function POST(req: Request) {
  const { messages } = await req.json();

  const openai = createOpenAI({
    baseURL: process.env.OPENAI_API_URL,
    apiKey: process.env.OPENAI_API_KEY,
  });

  // Build tools and system prompt dynamically from the YAML config
  const config = await loadLLMConfig();
  const { tools, systemPrompt } = buildToolsAndPrompt(config);

  const result = await streamText({
    model: openai.chat(env.OPENAI_API_MODEL || "gpt-4o-mini"),
    messages: await convertToModelMessages(messages),
    system: systemPrompt,
    tools,
    stopWhen: stepCountIs(5),
  });

  return result.toUIMessageStreamResponse();
}
