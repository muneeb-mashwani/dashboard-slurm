"use client"

import * as React from "react"
import { Line, LineChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart"

interface GpuNodeTimeSeriesChartProps {
  data: any[];
  nodes: string[];
}

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
]

export function GpuNodeTimeSeriesChart({ data, nodes }: GpuNodeTimeSeriesChartProps) {
  const chartConfig = nodes.reduce((config, node, index) => {
    config[node] = {
      label: node,
      color: COLORS[index % COLORS.length],
    }
    return config
  }, {} as ChartConfig)

  if (!data || data.length === 0 || nodes.length === 0) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>GPU Usage by Node</CardTitle>
          <CardDescription>
            GPU hours consumed over time for the busiest GPU nodes
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-48 text-muted-foreground">
          No GPU node data available for the selected period
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>GPU Usage by Node</CardTitle>
        <CardDescription>
          GPU hours consumed over time for the top {nodes.length} busiest GPU nodes
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-1 min-h-0">
        <ChartContainer config={chartConfig} className="h-full w-full">
          <LineChart accessibilityLayer data={data} margin={{ left: 12, right: 12 }}>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="date"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              tickFormatter={(value) => value.slice(5)}
            />
            <YAxis tickLine={false} axisLine={false} tickMargin={8} />
            <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
            <ChartLegend content={<ChartLegendContent />} />
            {nodes.map((node, index) => (
              <Line
                key={node}
                dataKey={node}
                type="monotone"
                stroke={COLORS[index % COLORS.length]}
                strokeWidth={2}
                dot={false}
                name={node}
              />
            ))}
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
