interface ExecutionCostInput {
  elapsedSeconds: number;
  allocatedCpus?: number;
  gpuCount?: number;
  nodes?: string;
  instanceTypeOverride?: string;
  startTime?: number;
  endTime?: number;
  cpuCostPerCoreHour?: number;
  gpuCostPerHour?: number;
}

export interface ExecutionCostBreakdown {
  cpuCost: number;
  gpuCost: number;
  totalCost: number;
  elapsedHours: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

const getEnv = (): Record<string, string | undefined> => {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  if (env) {
    return env;
  }
  return {};
};

const INSTANCE_SIZE_PARTS = new Set([
  "nano",
  "micro",
  "small",
  "medium",
  "large",
  "xlarge",
  "2xlarge",
  "4xlarge",
  "8xlarge",
  "10xlarge",
  "12xlarge",
  "16xlarge",
  "18xlarge",
  "24xlarge",
  "32xlarge",
  "48xlarge",
  "56xlarge",
  "metal",
]);

const isAsciiLowerAlpha = (char: string): boolean => char >= "a" && char <= "z";
const isDigit = (char: string): boolean => char >= "0" && char <= "9";

const isLikelyInstanceFamily = (value: string): boolean => {
  if (!value) return false;

  let sawLetter = false;
  let sawDigit = false;

  for (const char of value.toLowerCase()) {
    if (isAsciiLowerAlpha(char)) {
      sawLetter = true;
      continue;
    }
    if (isDigit(char)) {
      sawDigit = true;
      continue;
    }
    if (char === "-") {
      continue;
    }
    return false;
  }

  return sawLetter && sawDigit;
};

const asPositiveNumber = (value: unknown, fallback: number): number => {
  if (typeof value !== "number" || Number.isNaN(value) || value < 0) {
    return fallback;
  }
  return value;
};

const parseInstanceRates = (): Record<string, number> => {
  const env = getEnv();
  const raw = env.JOB_INSTANCE_HOURLY_RATES || env.NEXT_PUBLIC_JOB_INSTANCE_HOURLY_RATES;
  if (!raw) return {};

  try {
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    return Object.entries(parsed).reduce<Record<string, number>>((acc, [key, value]) => {
      const numeric = Number(value);
      if (key && Number.isFinite(numeric) && numeric >= 0) {
        acc[key.toLowerCase()] = numeric;
      }
      return acc;
    }, {});
  } catch {
    return {};
  }
};

export const extractInstanceTypeFromNodes = (nodes?: string): string | null => {
  if (!nodes) return null;

  const firstToken = nodes
    .split(/[,\s]+/)
    .map((token) => token.trim())
    .find((token) => token.length > 0);

  if (!firstToken) return null;

  const segments = firstToken.split("-").filter(Boolean);
  for (let index = 0; index < segments.length - 1; index += 1) {
    const family = segments[index]?.toLowerCase();
    const size = segments[index + 1]?.toLowerCase();
    if (family && size && isLikelyInstanceFamily(family) && INSTANCE_SIZE_PARTS.has(size)) {
      return `${family}.${size}`;
    }
  }

  const withoutIndex = firstToken.replace(/-\d+$/, "");
  return withoutIndex || firstToken;
};

const normalizeInstanceType = (value?: string | null): string | null => {
  if (!value) return null;
  const normalized = value.trim().toLowerCase();
  return normalized.length > 0 ? normalized : null;
};

const toEnvKey = (instanceType: string): string =>
  instanceType
    .replace(/[^a-zA-Z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "")
    .toUpperCase();

const resolveInstanceRate = (instanceType: string | null): number | null => {
  if (!instanceType) return null;

  const env = getEnv();

  const exactEnvValue = env[instanceType];
  if (exactEnvValue !== undefined) {
    const numeric = Number(exactEnvValue);
    if (Number.isFinite(numeric) && numeric >= 0) {
      return numeric;
    }
  }

  const directEnvValue = env[`JOB_INSTANCE_RATE_${toEnvKey(instanceType)}`];
  if (directEnvValue !== undefined) {
    const numeric = Number(directEnvValue);
    if (Number.isFinite(numeric) && numeric >= 0) {
      return numeric;
    }
  }

  const rates = parseInstanceRates();
  if (Object.keys(rates).length === 0) return null;

  const normalized = instanceType.toLowerCase();
  if (typeof rates[normalized] === "number") return rates[normalized];

  const partial = Object.entries(rates).find(([key]) => normalized.includes(key) || key.includes(normalized));
  return partial ? partial[1] : null;
};

const resolveElapsedSeconds = (input: ExecutionCostInput): number => {
  if (typeof input.startTime === "number" && input.startTime > 0) {
    const effectiveEnd = typeof input.endTime === "number" && input.endTime > 0
      ? input.endTime
      : Math.floor(Date.now() / 1000);
    return Math.max(0, effectiveEnd - input.startTime);
  }

  return Math.max(0, input.elapsedSeconds);
};

export function calculateExecutionCost(input: ExecutionCostInput): ExecutionCostBreakdown {
  const env = getEnv();
  const elapsedSeconds = resolveElapsedSeconds(input);
  const elapsedHours = elapsedSeconds / 3600;
  const instanceType = normalizeInstanceType(input.instanceTypeOverride) || extractInstanceTypeFromNodes(input.nodes);
  const instanceHourlyRate = resolveInstanceRate(instanceType);

  if (typeof instanceHourlyRate === "number") {
    return {
      cpuCost: 0,
      gpuCost: 0,
      totalCost: elapsedHours * instanceHourlyRate,
      elapsedHours,
      instanceType,
      instanceHourlyRate,
    };
  }

  const cpuRate = asPositiveNumber(
    input.cpuCostPerCoreHour,
    Number(env.JOB_CPU_COST_PER_CORE_HOUR ?? env.NEXT_PUBLIC_JOB_CPU_COST_PER_CORE_HOUR ?? 0.02)
  );
  const gpuRate = asPositiveNumber(
    input.gpuCostPerHour,
    Number(env.JOB_GPU_COST_PER_HOUR ?? env.NEXT_PUBLIC_JOB_GPU_COST_PER_HOUR ?? 0.5)
  );

  const cpuCount = Math.max(0, input.allocatedCpus ?? 0);
  const gpuCount = Math.max(0, input.gpuCount ?? 0);

  const cpuCost = cpuCount * elapsedHours * cpuRate;
  const gpuCost = gpuCount * elapsedHours * gpuRate;

  return {
    cpuCost,
    gpuCost,
    totalCost: cpuCost + gpuCost,
    elapsedHours,
    instanceType,
    instanceHourlyRate,
  };
}
