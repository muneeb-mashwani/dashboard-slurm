"use client";

import { useMemo, useState } from "react";
import useSWR from "swr";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search } from "lucide-react";

interface JobRow {
  jobId: string;
  userName: string;
  name: string;
  state: string;
  partition: string;
  nodes: string;
  startTime: number;
  endTime: number;
  elapsedSeconds: number;
  allocatedCpus: number;
  gpuCount: number;
  executionCost: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

interface JobDetails {
  jobId: string;
  userName: string;
  nodes: string;
  command: string;
  state: string[];
  cpusPerTask: number;
  allocatedCpus: number;
  memoryPerNodeGb: number;
  gresDetail: string[];
  outputPath: string;
  errorPath: string;
  inputPath: string;
  timeLimitMins: number;
  priority: number;
  executionCost: number;
  startTime: number;
  endTime: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

interface JobsDataResponse {
  jobs: JobRow[];
}

interface JobDetailsResponse {
  source: "active" | "completed";
  job: JobDetails;
}

const jsonFetcher = (url: string) => fetch(url).then((res) => res.json());

const formatDuration = (seconds: number): string => {
  if (seconds <= 0) return "-";
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours}h ${minutes}m`;
};

const formatTimestamp = (unixSeconds: number): string => {
  if (!unixSeconds || unixSeconds <= 0) return "-";
  return new Date(unixSeconds * 1000).toLocaleString();
};

const formatCurrency = (value: number): string => `$${value.toFixed(2)}`;

const stateBadgeVariant = (state: string): "default" | "secondary" | "destructive" => {
  if (state === "RUNNING") return "default";
  if (state === "FAILED" || state === "CANCELLED" || state === "TIMEOUT") return "destructive";
  return "secondary";
};

export default function JobsDataDashboard() {
  const [jobIdSearch, setJobIdSearch] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);

  const { data, isLoading, error } = useSWR<JobsDataResponse>("/api/slurm/jobs/executed?limit=1000", jsonFetcher, {
    refreshInterval: 60000,
  });

  const { data: detailsData, isLoading: detailsLoading } = useSWR<JobDetailsResponse>(
    selectedJobId ? `/api/slurm/job/details/${selectedJobId}` : null,
    jsonFetcher
  );

  const filteredJobs = useMemo(() => {
    const allJobs = data?.jobs || [];
    const normalizedJobId = jobIdSearch.trim().toLowerCase();
    const normalizedUser = userSearch.trim().toLowerCase();

    return allJobs.filter((job) => {
      const jobIdMatches = normalizedJobId ? job.jobId.toLowerCase().includes(normalizedJobId) : true;
      const userMatches = normalizedUser ? job.userName.toLowerCase().includes(normalizedUser) : true;
      return jobIdMatches && userMatches;
    });
  }, [data?.jobs, jobIdSearch, userSearch]);

  const selectedJob = detailsData?.job;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Jobs Data</CardTitle>
          <CardDescription>
            Browse executed jobs and inspect detailed execution metadata with estimated cost.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={jobIdSearch}
                onChange={(event) => setJobIdSearch(event.target.value)}
                placeholder="Search by job ID"
                className="pl-9"
              />
            </div>
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={userSearch}
                onChange={(event) => setUserSearch(event.target.value)}
                placeholder="Search by username"
                className="pl-9"
              />
            </div>
          </div>

          {error && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
              Failed to load jobs data from Slurm.
            </div>
          )}

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job ID</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>State</TableHead>
                  <TableHead>Partition</TableHead>
                  <TableHead>Instance</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && (
                  <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                      Loading jobs...
                    </TableCell>
                  </TableRow>
                )}

                {!isLoading && filteredJobs.length === 0 && (
                  <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                      No jobs found for the current filters.
                    </TableCell>
                  </TableRow>
                )}

                {!isLoading &&
                  filteredJobs.map((job) => (
                    <TableRow
                      key={job.jobId}
                      onClick={() => setSelectedJobId(job.jobId)}
                      className="cursor-pointer"
                      data-state={selectedJobId === job.jobId ? "selected" : undefined}
                    >
                      <TableCell className="font-mono">{job.jobId}</TableCell>
                      <TableCell>{job.userName}</TableCell>
                      <TableCell>
                        <Badge variant={stateBadgeVariant(job.state)}>{job.state}</Badge>
                      </TableCell>
                      <TableCell>{job.partition}</TableCell>
                      <TableCell className="font-mono">{job.instanceType || "-"}</TableCell>
                      <TableCell>{formatTimestamp(job.startTime)}</TableCell>
                      <TableCell>{formatDuration(job.elapsedSeconds)}</TableCell>
                      <TableCell className="font-medium">{formatCurrency(job.executionCost)}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Job Details</CardTitle>
          <CardDescription>
            Click a row to inspect nodes, command, resources, paths, and execution cost.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!selectedJobId && <p className="text-sm text-muted-foreground">Select a job to view details.</p>}

          {selectedJobId && detailsLoading && (
            <p className="text-sm text-muted-foreground">Loading job details...</p>
          )}

          {selectedJobId && !detailsLoading && selectedJob && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">Job ID</div>
                <div className="font-mono font-medium">{selectedJob.jobId}</div>
              </div>
              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">User</div>
                <div className="font-medium">{selectedJob.userName}</div>
              </div>

              <div className="rounded-md border p-3 md:col-span-2">
                <div className="text-muted-foreground">Nodes</div>
                <div className="font-medium">{selectedJob.nodes || "-"}</div>
              </div>

              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">Instance Type</div>
                <div className="font-mono">{selectedJob.instanceType || "-"}</div>
              </div>
              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">Instance Hourly Rate</div>
                <div className="font-medium">
                  {typeof selectedJob.instanceHourlyRate === "number"
                    ? formatCurrency(selectedJob.instanceHourlyRate)
                    : "Not configured"}
                </div>
              </div>

              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">Start Time</div>
                <div className="font-medium">{formatTimestamp(selectedJob.startTime)}</div>
              </div>
              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">End Time</div>
                <div className="font-medium">{formatTimestamp(selectedJob.endTime)}</div>
              </div>

              <div className="rounded-md border p-3 md:col-span-2">
                <div className="text-muted-foreground">Command</div>
                <div className="font-mono break-all">{selectedJob.command || "-"}</div>
              </div>

              <div className="rounded-md border p-3 md:col-span-2">
                <div className="text-muted-foreground">State</div>
                <div className="font-medium">{selectedJob.state.join(", ")}</div>
              </div>

              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">CPUs Per Task</div>
                <div className="font-medium">{selectedJob.cpusPerTask || selectedJob.allocatedCpus || "-"}</div>
              </div>
              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">Memory per Node (GB)</div>
                <div className="font-medium">{selectedJob.memoryPerNodeGb ? selectedJob.memoryPerNodeGb.toFixed(2) : "-"}</div>
              </div>

              <div className="rounded-md border p-3 md:col-span-2">
                <div className="text-muted-foreground">Gres Detail</div>
                <div className="font-medium">{selectedJob.gresDetail?.length ? selectedJob.gresDetail.join(", ") : "-"}</div>
              </div>

              <div className="rounded-md border p-3 md:col-span-2">
                <div className="text-muted-foreground">Output Path</div>
                <div className="font-mono break-all">{selectedJob.outputPath || "-"}</div>
              </div>
              <div className="rounded-md border p-3 md:col-span-2">
                <div className="text-muted-foreground">Error Path</div>
                <div className="font-mono break-all">{selectedJob.errorPath || "-"}</div>
              </div>
              <div className="rounded-md border p-3 md:col-span-2">
                <div className="text-muted-foreground">Input Path</div>
                <div className="font-mono break-all">{selectedJob.inputPath || "-"}</div>
              </div>

              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">Time Limit (mins)</div>
                <div className="font-medium">{selectedJob.timeLimitMins || "-"}</div>
              </div>
              <div className="rounded-md border p-3">
                <div className="text-muted-foreground">Priority</div>
                <div className="font-medium">{selectedJob.priority || "-"}</div>
              </div>

              <div className="rounded-md border p-3 md:col-span-2 bg-muted/40">
                <div className="text-muted-foreground">Cost of execution</div>
                <div className="text-lg font-semibold">{formatCurrency(selectedJob.executionCost || 0)}</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
