export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { fetchSlurmData } from "@/lib/slurm-api";
import { calculateExecutionCost } from "@/lib/job-cost";

const getEnv = (): Record<string, string | undefined> => {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  if (env) {
    return env;
  }
  return {};
};

interface NumericField {
  number?: number;
}

interface SlurmTresEntry {
  type?: string;
  name?: string;
  count?: number;
}

interface SlurmJobRecord {
  job_id?: string | number;
  user?: string;
  user_name?: string;
  name?: string;
  comment?: string;
  admin_comment?: string;
  system_comment?: string;
  extra?: string;
  job_state?: string | string[];
  state?: { current?: string[]; reason?: string };
  partition?: string;
  nodes?: string;
  time?: {
    start?: number;
    end?: number;
    elapsed?: number;
    limit?: { number?: number };
  };
  start_time?: NumericField;
  end_time?: NumericField;
  submit_time?: NumericField;
  cpus_per_task?: NumericField;
  cpus?: NumericField;
  required?: {
    CPUs?: number;
    memory_per_node?: NumericField;
  };
  tres?: {
    allocated?: SlurmTresEntry[];
    requested?: SlurmTresEntry[];
  };
  tres_req_str?: string;
  gres_detail?: string[];
}

interface NormalizedJobRow {
  jobId: string;
  userName: string;
  name: string;
  state: string;
  partition: string;
  nodes: string;
  startTime: number;
  endTime: number;
  elapsedSeconds: number;
  allocatedCpus: number;
  gpuCount: number;
  executionCost: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
  jobKey: string;
  instanceId: string | null;
}

const isAlphaNumeric = (char: string): boolean => {
  const lower = char.toLowerCase();
  return (lower >= "a" && lower <= "z") || (char >= "0" && char <= "9");
};

const isValidInstanceTypeEnvKey = (key: string): boolean => {
  const normalized = key.toLowerCase().trim();
  const dotIndex = normalized.indexOf(".");
  if (dotIndex <= 0 || dotIndex >= normalized.length - 1) return false;

  const family = normalized.slice(0, dotIndex);
  const size = normalized.slice(dotIndex + 1);
  if (!(family[0] >= "a" && family[0] <= "z")) return false;

  let familyHasDigit = false;
  for (const char of family) {
    if (char >= "0" && char <= "9") {
      familyHasDigit = true;
      continue;
    }
    if ((char >= "a" && char <= "z") || char === "-") continue;
    return false;
  }

  if (!familyHasDigit) return false;

  for (const char of size) {
    if (!isAlphaNumeric(char)) return false;
  }

  return size.length > 0;
};

const readStringField = (value: unknown): string | null => {
  if (typeof value === "string") {
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }

  if (value && typeof value === "object") {
    const candidate = value as { string?: unknown; value?: unknown };
    if (typeof candidate.string === "string") {
      const normalized = candidate.string.trim();
      return normalized.length > 0 ? normalized : null;
    }
    if (typeof candidate.value === "string") {
      const normalized = candidate.value.trim();
      return normalized.length > 0 ? normalized : null;
    }
  }

  return null;
};

const extractInstanceTypeFromComment = (...candidates: unknown[]): string | null => {
  for (const candidate of candidates) {
    const text = readStringField(candidate);
    if (!text) continue;

    const match = /ec2instancetype\s*=\s*([a-z0-9.-]+)/i.exec(text);
    if (!match?.[1]) continue;

    const value = match[1].trim().replace(/^['"]|['"]$/g, "");
    if (value) return value.toLowerCase();
  }

  return null;
};

const extractInstanceIdFromComment = (...candidates: unknown[]): string | null => {
  for (const candidate of candidates) {
    const text = readStringField(candidate);
    if (!text) continue;

    const match = /ec2instanceid\s*=\s*([a-z0-9-]+)/i.exec(text);
    if (!match?.[1]) continue;

    const value = match[1].trim().replace(/^['"]|['"]$/g, "");
    if (value) return value.toLowerCase();
  }

  return null;
};

const getConfiguredInstanceTypes = (env: Record<string, string | undefined>): string[] => {
  const instanceTypes: string[] = [];

  for (const [key, value] of Object.entries(env)) {
    if (!isValidInstanceTypeEnvKey(key)) continue;

    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric < 0) continue;
    instanceTypes.push(key.toLowerCase());
  }

  return Array.from(new Set(instanceTypes));
};

const selectCpuDefault = (configured: string[]): string | null => {
  const preferred = ["m5.xlarge", "c5.2xlarge", "r5.2xlarge"];
  for (const candidate of preferred) {
    if (configured.includes(candidate)) return candidate;
  }

  const nonGpu = configured.find((type) => !type.startsWith("g"));
  return nonGpu || null;
};

const selectGpuDefault = (configured: string[]): string | null => {
  if (configured.includes("g5.xlarge")) return "g5.xlarge";
  const gpu = configured.find((type) => type.startsWith("g"));
  return gpu || null;
};

const inferInstanceTypeFromHints = (
  partition: string | undefined,
  nodes: string | undefined,
  configured: string[]
): string | null => {
  if (configured.length === 0) return null;

  const hints = `${partition || ""} ${nodes || ""}`.toLowerCase();
  if (hints.includes("gpu")) {
    return selectGpuDefault(configured);
  }

  if (hints.includes("cpu")) {
    return selectCpuDefault(configured);
  }

  return null;
};

const toNumber = (value: unknown, fallback = 0): number => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  return fallback;
};

const isFutureStartTimeWithinWindow = (startTime: number): boolean => {
  if (!Number.isFinite(startTime) || startTime <= 0) return true;

  const nowInSeconds = Math.floor(Date.now() / 1000);
  const maxFutureSkewSeconds = 24 * 60 * 60;
  return startTime <= nowInSeconds + maxFutureSkewSeconds;
};

const parseGpuCountFromText = (text?: string): number => {
  if (!text) return 0;
  const matches = text.match(/gpu(?::[^:,]+)?:(\d+)/gi);
  if (!matches) return 0;

  return matches.reduce((sum, token) => {
    const parts = token.split(":");
    const count = Number(parts.at(-1));
    return sum + (Number.isFinite(count) ? count : 0);
  }, 0);
};

const getPrimaryState = (job: SlurmJobRecord): string => {
  if (Array.isArray(job.job_state) && job.job_state.length > 0) return job.job_state[0];
  if (typeof job.job_state === "string") return job.job_state;
  if (job.state?.current?.length) return job.state.current[0];
  return "UNKNOWN";
};

const normalizeState = (value: string): string => value.toUpperCase().replace(/^JOB_/, "");

const hasTerminalState = (state: string): boolean => {
  const normalized = normalizeState(state);
  return normalized === "COMPLETED" || normalized === "TIMEOUT" || normalized.startsWith("CANCELLED");
};

const getAllStates = (job: SlurmJobRecord): string[] => {
  const states: string[] = [];

  if (Array.isArray(job.job_state)) {
    states.push(...job.job_state.filter((value): value is string => typeof value === "string"));
  } else if (typeof job.job_state === "string") {
    states.push(job.job_state);
  }

  if (Array.isArray(job.state?.current)) {
    states.push(...job.state.current.filter((value): value is string => typeof value === "string"));
  }

  return states;
};

const isExecutedOrCancelled = (job: SlurmJobRecord): boolean => {
  const states = getAllStates(job);
  return states.some((state) => hasTerminalState(state));
};

const countTerminalJobs = (candidateData: any): number => {
  const candidateJobs = Array.isArray(candidateData?.jobs) ? (candidateData.jobs as SlurmJobRecord[]) : [];
  return candidateJobs.reduce((count, job) => count + (isExecutedOrCancelled(job) ? 1 : 0), 0);
};

const getElapsedSeconds = (job: SlurmJobRecord): number => {
  if (typeof job.time?.elapsed === "number") return Math.max(0, job.time.elapsed);

  const start = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
  const end = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
  if (!start) return 0;

  const effectiveEnd = end > 0 ? end : Math.floor(Date.now() / 1000);
  return Math.max(0, effectiveEnd - start);
};

const getAllocatedCpus = (job: SlurmJobRecord): number => {
  const fromTres = job.tres?.allocated?.find((item) => item.type?.toLowerCase() === "cpu")?.count;
  if (typeof fromTres === "number") return Math.max(0, fromTres);

  return Math.max(
    0,
    toNumber(job.required?.CPUs, 0) || toNumber(job.cpus_per_task?.number, 0) || toNumber(job.cpus?.number, 0)
  );
};

const getGpuCount = (job: SlurmJobRecord): number => {
  const tresGpu = (job.tres?.allocated || [])
    .filter((item) => item.type?.toLowerCase() === "gres" && item.name?.toLowerCase().includes("gpu"))
    .reduce((sum, item) => sum + toNumber(item.count, 0), 0);

  if (tresGpu > 0) return tresGpu;

  const gresDetail = Array.isArray(job.gres_detail) ? job.gres_detail.join(",") : "";
  const fromDetail = parseGpuCountFromText(gresDetail);
  if (fromDetail > 0) return fromDetail;

  return parseGpuCountFromText(job.tres_req_str);
};

const buildJobKey = (jobId: string, userName: string, startTime: number, state: string): string =>
  [jobId, userName, startTime, state].join("::");

const getInstanceGroupKey = (job: NormalizedJobRow): string | null => {
  if (job.instanceId) {
    return `instance:${job.instanceId}`;
  }

  if (job.nodes && job.nodes !== "-") {
    return `node:${job.nodes}`;
  }

  return null;
};

const addSharedSeconds = (target: Map<string, number>, jobKey: string, seconds: number): void => {
  target.set(jobKey, (target.get(jobKey) || 0) + seconds);
};

const distributeGroupSegment = (
  groupJobs: NormalizedJobRow[],
  left: number,
  right: number,
  sharedSecondsByJobKey: Map<string, number>
): void => {
  if (right <= left) return;

  const active = groupJobs.filter((job) => job.startTime < right && job.endTime > left);
  if (active.length === 0) return;

  const shared = (right - left) / active.length;
  for (const job of active) {
    addSharedSeconds(sharedSecondsByJobKey, job.jobKey, shared);
  }
};

const distributeGroupCost = (groupJobs: NormalizedJobRow[], sharedSecondsByJobKey: Map<string, number>): void => {
  if (groupJobs.length === 1) {
    const only = groupJobs[0];
    if (only) {
      addSharedSeconds(sharedSecondsByJobKey, only.jobKey, only.endTime - only.startTime);
    }
    return;
  }

  const boundaries = Array.from(new Set(groupJobs.flatMap((job) => [job.startTime, job.endTime]))).sort((a, b) => a - b);

  for (let index = 0; index < boundaries.length - 1; index += 1) {
    const left = boundaries[index];
    const right = boundaries[index + 1];
    if (left === undefined || right === undefined) continue;
    distributeGroupSegment(groupJobs, left, right, sharedSecondsByJobKey);
  }
};

const applyConcurrentInstanceCost = (jobs: NormalizedJobRow[]): NormalizedJobRow[] => {
  const grouped = new Map<string, NormalizedJobRow[]>();

  for (const job of jobs) {
    const hasInterval = job.startTime > 0 && job.endTime > job.startTime;
    if (!hasInterval || typeof job.instanceHourlyRate !== "number") {
      continue;
    }

    const instanceKey = getInstanceGroupKey(job);
    if (!instanceKey) continue;

    const list = grouped.get(instanceKey);
    if (list) {
      list.push(job);
    } else {
      grouped.set(instanceKey, [job]);
    }
  }

  const sharedSecondsByJobKey = new Map<string, number>();

  for (const groupJobs of grouped.values()) {
    distributeGroupCost(groupJobs, sharedSecondsByJobKey);
  }

  return jobs.map((job) => {
    if (typeof job.instanceHourlyRate !== "number") {
      return job;
    }

    const sharedSeconds = sharedSecondsByJobKey.get(job.jobKey);
    if (typeof sharedSeconds !== "number") {
      return job;
    }

    return {
      ...job,
      executionCost: (sharedSeconds / 3600) * job.instanceHourlyRate,
    };
  });
};

const buildLiveCommentMap = async (): Promise<Map<string, string>> => {
  const liveJobsResponse = await fetchSlurmData("/jobs", { type: "slurm" });
  const liveJobs = Array.isArray(liveJobsResponse.data?.jobs) ? (liveJobsResponse.data.jobs as SlurmJobRecord[]) : [];
  const liveCommentByJobId = new Map<string, string>();

  for (const liveJob of liveJobs) {
    const liveJobId = String(liveJob.job_id ?? "").trim();
    if (!liveJobId) continue;

    const text =
      readStringField(liveJob.comment) ||
      readStringField(liveJob.admin_comment) ||
      readStringField(liveJob.system_comment) ||
      readStringField(liveJob.extra);

    if (text) {
      liveCommentByJobId.set(liveJobId, text);
    }
  }

  return liveCommentByJobId;
};

export async function GET(req: Request) {
  const env = getEnv();
  const url = new URL(req.url);
  const pageSize = Math.min(Math.max(Number(url.searchParams.get("pageSize") || url.searchParams.get("limit") || "50000"), 1), 200000);
  const requestedPage = Math.max(Number(url.searchParams.get("page") || "1"), 1);
  const jobIdFilter = url.searchParams.get("jobId")?.trim().toLowerCase() || "";
  const userFilter = url.searchParams.get("user")?.trim().toLowerCase() || "";
  const requestedLookbackHours = Number(
    url.searchParams.get("lookbackHours") ||
    env.JOBS_DATA_LOOKBACK_HOURS ||
    "1"
  );
  const lookbackHours = Number.isFinite(requestedLookbackHours) && requestedLookbackHours > 0
    ? Math.min(requestedLookbackHours, 24)
    : 1;
  const requestedExcludeRecentHours = Number(url.searchParams.get("excludeRecentHours") || "0");
  const excludeRecentHours = Number.isFinite(requestedExcludeRecentHours) && requestedExcludeRecentHours >= 0
    ? requestedExcludeRecentHours
    : 0;

  const nowEpoch = Math.floor(Date.now() / 1000);
  const windowEndEpoch = nowEpoch - excludeRecentHours * 60 * 60;
  const startTimeEpoch = windowEndEpoch - lookbackHours * 60 * 60;
  const endpoints = [
    `/jobs?state=completed,cancelled,timeout&start_time=${startTimeEpoch}`,
    `/jobs?state=completed,cancelled,timeout`,
    `/jobs?start_time=${startTimeEpoch}`,
    "/jobs",
  ];

  let data: any = undefined;
  let error: string | undefined = undefined;
  let status: number | undefined = undefined;
  let selectedEndpoint: string | null = null;
  let selectedJobsCount = -1;
  let selectedTerminalCount = -1;
  let selectedSource: "slurmdb" | "slurm" = "slurmdb";

  // Query all fallbacks and keep the successful response with the largest jobs set.
  for (const endpoint of endpoints) {
    const response = await fetchSlurmData(endpoint, { type: "slurmdb" });

    if (response.error) {
      error = response.error;
      status = response.status;
      continue;
    }

    const jobsCount = Array.isArray(response.data?.jobs) ? response.data.jobs.length : 0;
    const terminalCount = countTerminalJobs(response.data);
    const isBetterCandidate = jobsCount > selectedJobsCount;

    if (isBetterCandidate) {
      data = response.data;
      selectedJobsCount = jobsCount;
      selectedTerminalCount = terminalCount;
      selectedEndpoint = endpoint;
    }

    error = undefined;
    status = undefined;
  }

  // If slurmdb yields no usable data, fallback to slurm jobs endpoint.
  if ((!data || selectedJobsCount <= 0) && !error) {
    const slurmResponse = await fetchSlurmData("/jobs", { type: "slurm" });
    if (!slurmResponse.error) {
      data = slurmResponse.data;
      selectedEndpoint = "/jobs";
      selectedJobsCount = Array.isArray(slurmResponse.data?.jobs) ? slurmResponse.data.jobs.length : 0;
      selectedTerminalCount = countTerminalJobs(slurmResponse.data);
      selectedSource = "slurm";
    } else {
      error = slurmResponse.error;
      status = slurmResponse.status;
    }
  }

  if (error) {
    return NextResponse.json({ error }, { status: typeof status === "number" ? status : 500 });
  }

  const jobs = Array.isArray(data?.jobs) ? (data.jobs as SlurmJobRecord[]) : [];
  const liveCommentByJobId = await buildLiveCommentMap();
  const configuredInstanceTypes = getConfiguredInstanceTypes(env);

  const normalizedJobs = jobs
    .map((job) => {
      const jobId = String(job.job_id ?? "").trim();
      if (!jobId) return null;

      const state = getPrimaryState(job);
      if (!isExecutedOrCancelled(job)) return null;

      const startTime = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
      if (!isFutureStartTimeWithinWindow(startTime)) return null;
      if (startTime < startTimeEpoch || startTime > windowEndEpoch) return null;

      const endTime = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
      const elapsedSeconds = getElapsedSeconds(job);
      const allocatedCpus = getAllocatedCpus(job);
      const gpuCount = getGpuCount(job);
      const instanceTypeFromComment = extractInstanceTypeFromComment(
        job.comment,
        job.admin_comment,
        job.system_comment,
        job.extra,
        liveCommentByJobId.get(jobId)
      );
      const inferredInstanceType = inferInstanceTypeFromHints(job.partition, job.nodes, configuredInstanceTypes);
      const instanceIdFromComment = extractInstanceIdFromComment(
        job.comment,
        job.admin_comment,
        job.system_comment,
        job.extra,
        liveCommentByJobId.get(jobId)
      );
      const cost = calculateExecutionCost({
        elapsedSeconds,
        allocatedCpus,
        gpuCount,
        nodes: job.nodes,
        instanceTypeOverride: instanceTypeFromComment ?? inferredInstanceType ?? undefined,
        startTime,
        endTime,
      });

      return {
        jobId,
        userName: job.user_name || job.user || "unknown",
        name: job.name || "Unnamed Job",
        state,
        partition: job.partition || "-",
        nodes: job.nodes || "-",
        startTime,
        endTime,
        elapsedSeconds,
        allocatedCpus,
        gpuCount,
        executionCost: cost.totalCost,
        instanceType: cost.instanceType,
        instanceHourlyRate: cost.instanceHourlyRate,
        jobKey: buildJobKey(jobId, job.user_name || job.user || "unknown", startTime, state),
        instanceId: instanceIdFromComment,
      };
    })
    .filter((job): job is NonNullable<typeof job> => Boolean(job));

  const concurrentCostAdjustedJobs = applyConcurrentInstanceCost(normalizedJobs)
    .sort((a, b) => {
      if (b.startTime !== a.startTime) return b.startTime - a.startTime;
      return Number(b.jobId) - Number(a.jobId);
    })
    .map(({ instanceId: _instanceId, ...job }) => job);

  const filteredJobs = concurrentCostAdjustedJobs.filter((job) => {
    const jobIdMatches = jobIdFilter ? job.jobId.toLowerCase().includes(jobIdFilter) : true;
    const userMatches = userFilter ? job.userName.toLowerCase().includes(userFilter) : true;
    return jobIdMatches && userMatches;
  });

  const totalCount = filteredJobs.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const page = Math.min(requestedPage, totalPages);
  const startIndex = (page - 1) * pageSize;
  const paginatedJobs = filteredJobs.slice(startIndex, startIndex + pageSize);

  return NextResponse.json({
    jobs: paginatedJobs,
    meta: {
      count: paginatedJobs.length,
      totalCount,
      page,
      pageSize,
      totalPages,
      lookbackHours,
      excludeRecentHours,
      windowEndEpoch,
      jobIdFilter,
      userFilter,
      selectedEndpoint,
      selectedSource,
      selectedJobsCount,
      selectedTerminalCount,
      cpuCostPerCoreHour: Number(env.JOB_CPU_COST_PER_CORE_HOUR ?? env.NEXT_PUBLIC_JOB_CPU_COST_PER_CORE_HOUR ?? 0.02),
      gpuCostPerHour: Number(env.JOB_GPU_COST_PER_HOUR ?? env.NEXT_PUBLIC_JOB_GPU_COST_PER_HOUR ?? 0.5),
    },
  });
}
