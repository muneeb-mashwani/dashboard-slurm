export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { fetchSlurmData } from "@/lib/slurm-api";
import { calculateExecutionCost } from "@/lib/job-cost";

const getEnv = (): Record<string, string | undefined> => {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  if (env) {
    return env;
  }
  return {};
};

interface NumericField {
  number?: number;
}

interface SlurmTresEntry {
  type?: string;
  name?: string;
  count?: number;
}

interface SlurmJobRecord {
  job_id?: string | number;
  user?: string;
  user_name?: string;
  name?: string;
  comment?: string;
  admin_comment?: string;
  system_comment?: string;
  extra?: string;
  job_state?: string | string[];
  state?: { current?: string[]; reason?: string };
  partition?: string;
  nodes?: string;
  time?: {
    start?: number;
    end?: number;
    elapsed?: number;
    limit?: { number?: number };
  };
  start_time?: NumericField;
  end_time?: NumericField;
  submit_time?: NumericField;
  cpus_per_task?: NumericField;
  cpus?: NumericField;
  required?: {
    CPUs?: number;
    memory_per_node?: NumericField;
  };
  tres?: {
    allocated?: SlurmTresEntry[];
    requested?: SlurmTresEntry[];
  };
  tres_req_str?: string;
  gres_detail?: string[];
}

interface NormalizedJobRow {
  jobId: string;
  userName: string;
  name: string;
  state: string;
  partition: string;
  nodes: string;
  startTime: number;
  endTime: number;
  elapsedSeconds: number;
  allocatedCpus: number;
  gpuCount: number;
  executionCost: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
  jobKey: string;
  instanceId: string | null;
}

const readStringField = (value: unknown): string | null => {
  if (typeof value === "string") {
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }

  if (value && typeof value === "object") {
    const candidate = value as { string?: unknown; value?: unknown };
    if (typeof candidate.string === "string") {
      const normalized = candidate.string.trim();
      return normalized.length > 0 ? normalized : null;
    }
    if (typeof candidate.value === "string") {
      const normalized = candidate.value.trim();
      return normalized.length > 0 ? normalized : null;
    }
  }

  return null;
};

const extractInstanceTypeFromComment = (...candidates: unknown[]): string | null => {
  for (const candidate of candidates) {
    const text = readStringField(candidate);
    if (!text) continue;

    const match = /ec2instancetype\s*=\s*([a-z0-9.-]+)/i.exec(text);
    if (!match?.[1]) continue;

    const value = match[1].trim().replace(/^['"]|['"]$/g, "");
    if (value) return value.toLowerCase();
  }

  return null;
};

const extractInstanceIdFromComment = (...candidates: unknown[]): string | null => {
  for (const candidate of candidates) {
    const text = readStringField(candidate);
    if (!text) continue;

    const match = /ec2instanceid\s*=\s*([a-z0-9-]+)/i.exec(text);
    if (!match?.[1]) continue;

    const value = match[1].trim().replace(/^['"]|['"]$/g, "");
    if (value) return value.toLowerCase();
  }

  return null;
};

const toNumber = (value: unknown, fallback = 0): number => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  return fallback;
};

const parseGpuCountFromText = (text?: string): number => {
  if (!text) return 0;
  const matches = text.match(/gpu(?::[^:,]+)?:(\d+)/gi);
  if (!matches) return 0;

  return matches.reduce((sum, token) => {
    const parts = token.split(":");
    const count = Number(parts.at(-1));
    return sum + (Number.isFinite(count) ? count : 0);
  }, 0);
};

const getPrimaryState = (job: SlurmJobRecord): string => {
  if (Array.isArray(job.job_state) && job.job_state.length > 0) return job.job_state[0];
  if (typeof job.job_state === "string") return job.job_state;
  if (job.state?.current?.length) return job.state.current[0];
  return "UNKNOWN";
};

const isExecutedOrCancelled = (state: string): boolean => {
  const normalized = state.toUpperCase();
  return normalized === "COMPLETED" || normalized.startsWith("CANCELLED");
};

const getElapsedSeconds = (job: SlurmJobRecord): number => {
  if (typeof job.time?.elapsed === "number") return Math.max(0, job.time.elapsed);

  const start = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
  const end = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
  if (!start) return 0;

  const effectiveEnd = end > 0 ? end : Math.floor(Date.now() / 1000);
  return Math.max(0, effectiveEnd - start);
};

const getAllocatedCpus = (job: SlurmJobRecord): number => {
  const fromTres = job.tres?.allocated?.find((item) => item.type?.toLowerCase() === "cpu")?.count;
  if (typeof fromTres === "number") return Math.max(0, fromTres);

  return Math.max(
    0,
    toNumber(job.required?.CPUs, 0) || toNumber(job.cpus_per_task?.number, 0) || toNumber(job.cpus?.number, 0)
  );
};

const getGpuCount = (job: SlurmJobRecord): number => {
  const tresGpu = (job.tres?.allocated || [])
    .filter((item) => item.type?.toLowerCase() === "gres" && item.name?.toLowerCase().includes("gpu"))
    .reduce((sum, item) => sum + toNumber(item.count, 0), 0);

  if (tresGpu > 0) return tresGpu;

  const gresDetail = Array.isArray(job.gres_detail) ? job.gres_detail.join(",") : "";
  const fromDetail = parseGpuCountFromText(gresDetail);
  if (fromDetail > 0) return fromDetail;

  return parseGpuCountFromText(job.tres_req_str);
};

const buildJobKey = (jobId: string, userName: string, startTime: number, state: string): string =>
  [jobId, userName, startTime, state].join("::");

const applyConcurrentInstanceCost = (jobs: NormalizedJobRow[]): NormalizedJobRow[] => {
  const grouped = new Map<string, NormalizedJobRow[]>();

  for (const job of jobs) {
    const hasInterval = job.startTime > 0 && job.endTime > job.startTime;
    if (!hasInterval || typeof job.instanceHourlyRate !== "number") {
      continue;
    }

    const instanceKey = job.instanceId ? `instance:${job.instanceId}` : (job.nodes && job.nodes !== "-" ? `node:${job.nodes}` : null);
    if (!instanceKey) continue;

    const list = grouped.get(instanceKey);
    if (list) {
      list.push(job);
    } else {
      grouped.set(instanceKey, [job]);
    }
  }

  const sharedSecondsByJobKey = new Map<string, number>();

  for (const groupJobs of grouped.values()) {
    if (groupJobs.length <= 1) {
      const only = groupJobs[0];
      if (only) {
        sharedSecondsByJobKey.set(only.jobKey, only.endTime - only.startTime);
      }
      continue;
    }

    const boundaries = Array.from(
      new Set(groupJobs.flatMap((job) => [job.startTime, job.endTime]))
    ).sort((a, b) => a - b);

    for (let index = 0; index < boundaries.length - 1; index += 1) {
      const left = boundaries[index];
      const right = boundaries[index + 1];
      if (left === undefined || right === undefined || right <= left) continue;

      const active = groupJobs.filter((job) => job.startTime < right && job.endTime > left);
      if (active.length === 0) continue;

      const segment = right - left;
      const shared = segment / active.length;

      for (const job of active) {
        sharedSecondsByJobKey.set(job.jobKey, (sharedSecondsByJobKey.get(job.jobKey) || 0) + shared);
      }
    }
  }

  return jobs.map((job) => {
    if (typeof job.instanceHourlyRate !== "number") {
      return job;
    }

    const sharedSeconds = sharedSecondsByJobKey.get(job.jobKey);
    if (typeof sharedSeconds !== "number") {
      return job;
    }

    return {
      ...job,
      executionCost: (sharedSeconds / 3600) * job.instanceHourlyRate,
    };
  });
};

const buildLiveCommentMap = async (): Promise<Map<string, string>> => {
  const liveJobsResponse = await fetchSlurmData("/jobs", { type: "slurm" });
  const liveJobs = Array.isArray(liveJobsResponse.data?.jobs) ? (liveJobsResponse.data.jobs as SlurmJobRecord[]) : [];
  const liveCommentByJobId = new Map<string, string>();

  for (const liveJob of liveJobs) {
    const liveJobId = String(liveJob.job_id ?? "").trim();
    if (!liveJobId) continue;

    const text =
      readStringField(liveJob.comment) ||
      readStringField(liveJob.admin_comment) ||
      readStringField(liveJob.system_comment) ||
      readStringField(liveJob.extra);

    if (text) {
      liveCommentByJobId.set(liveJobId, text);
    }
  }

  return liveCommentByJobId;
};

export async function GET(req: Request) {
  const env = getEnv();
  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") || "2000"), 1), 50000);
  const lookbackDays = Math.max(
    1,
    Number(
      url.searchParams.get("lookbackDays") || env.JOBS_DATA_LOOKBACK_DAYS || "365"
    )
  );

  const startTimeEpoch = Math.floor(Date.now() / 1000) - lookbackDays * 24 * 60 * 60;
  const endpoints = [
    `/jobs?state=completed,cancelled&start_time=${startTimeEpoch}`,
    "/jobs?state=completed,cancelled",
    "/jobs",
  ];

  let data: any = undefined;
  let error: string | undefined = undefined;
  let status: number | undefined = undefined;

  // Try progressively broader queries. Continue on both "error" and "empty result".
  for (const endpoint of endpoints) {
    const response = await fetchSlurmData(endpoint, { type: "slurmdb" });

    if (response.error) {
      error = response.error;
      status = response.status;
      continue;
    }

    data = response.data;
    error = undefined;
    status = undefined;

    if (Array.isArray(data?.jobs) && data.jobs.length > 0) {
      break;
    }
  }

  if (error) {
    return NextResponse.json({ error }, { status: typeof status === "number" ? status : 500 });
  }

  const jobs = Array.isArray(data?.jobs) ? (data.jobs as SlurmJobRecord[]) : [];
  const liveCommentByJobId = await buildLiveCommentMap();

  const normalizedJobs = jobs
    .map((job) => {
      const jobId = String(job.job_id ?? "").trim();
      if (!jobId) return null;

      const state = getPrimaryState(job);
      if (!isExecutedOrCancelled(state)) return null;

      const startTime = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
      const endTime = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
      const elapsedSeconds = getElapsedSeconds(job);
      const allocatedCpus = getAllocatedCpus(job);
      const gpuCount = getGpuCount(job);
      const instanceTypeFromComment = extractInstanceTypeFromComment(
        job.comment,
        job.admin_comment,
        job.system_comment,
        job.extra,
        liveCommentByJobId.get(jobId)
      );
      const instanceIdFromComment = extractInstanceIdFromComment(
        job.comment,
        job.admin_comment,
        job.system_comment,
        job.extra,
        liveCommentByJobId.get(jobId)
      );
      const cost = calculateExecutionCost({
        elapsedSeconds,
        allocatedCpus,
        gpuCount,
        nodes: job.nodes,
        instanceTypeOverride: instanceTypeFromComment ?? undefined,
        startTime,
        endTime,
      });

      return {
        jobId,
        userName: job.user_name || job.user || "unknown",
        name: job.name || "Unnamed Job",
        state,
        partition: job.partition || "-",
        nodes: job.nodes || "-",
        startTime,
        endTime,
        elapsedSeconds,
        allocatedCpus,
        gpuCount,
        executionCost: cost.totalCost,
        instanceType: cost.instanceType,
        instanceHourlyRate: cost.instanceHourlyRate,
        jobKey: buildJobKey(jobId, job.user_name || job.user || "unknown", startTime, state),
        instanceId: instanceIdFromComment,
      };
    })
    .filter((job): job is NonNullable<typeof job> => Boolean(job));

  const concurrentCostAdjustedJobs = applyConcurrentInstanceCost(normalizedJobs)
    .sort((a, b) => {
      if (b.startTime !== a.startTime) return b.startTime - a.startTime;
      return Number(b.jobId) - Number(a.jobId);
    })
    .slice(0, limit)
    .map(({ instanceId: _instanceId, ...job }) => job);

  return NextResponse.json({
    jobs: concurrentCostAdjustedJobs,
    meta: {
      count: concurrentCostAdjustedJobs.length,
      limit,
      lookbackDays,
      cpuCostPerCoreHour: Number(env.JOB_CPU_COST_PER_CORE_HOUR ?? env.NEXT_PUBLIC_JOB_CPU_COST_PER_CORE_HOUR ?? 0.02),
      gpuCostPerHour: Number(env.JOB_GPU_COST_PER_HOUR ?? env.NEXT_PUBLIC_JOB_GPU_COST_PER_HOUR ?? 0.5),
    },
  });
}
