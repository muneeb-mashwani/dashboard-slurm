import Footer from "@/components/footer/footer";
import UnifiedHeader from "@/components/unified-header";
import JobsDataDashboard from "@/components/jobs/jobs-data-dashboard";

const env = process.env;

export const dynamic = "force-dynamic";

export default function JobsDataPage() {
  return (
    <div className="mb-5">
      <div className="flex-1 space-y-4 p-2 ml-2 mx-auto bg-background min-h-screen">
        <UnifiedHeader
          title="Jobs Data"
          description="Executed jobs table with search, details, and execution cost."
        />
        <JobsDataDashboard />
      </div>
      <Footer cluster={env.CLUSTER_NAME} logo={env.CLUSTER_LOGO} />
    </div>
  );
}
