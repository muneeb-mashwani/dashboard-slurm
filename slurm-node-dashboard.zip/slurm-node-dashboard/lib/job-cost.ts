interface ExecutionCostInput {
  elapsedSeconds: number;
  allocatedCpus?: number;
  gpuCount?: number;
  nodes?: string;
  startTime?: number;
  endTime?: number;
  cpuCostPerCoreHour?: number;
  gpuCostPerHour?: number;
}

export interface ExecutionCostBreakdown {
  cpuCost: number;
  gpuCost: number;
  totalCost: number;
  elapsedHours: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

const asPositiveNumber = (value: unknown, fallback: number): number => {
  if (typeof value !== "number" || Number.isNaN(value) || value < 0) {
    return fallback;
  }
  return value;
};

const parseInstanceRates = (): Record<string, number> => {
  const raw = process.env.JOB_INSTANCE_HOURLY_RATES || process.env.NEXT_PUBLIC_JOB_INSTANCE_HOURLY_RATES;
  if (!raw) return {};

  try {
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    return Object.entries(parsed).reduce<Record<string, number>>((acc, [key, value]) => {
      const numeric = Number(value);
      if (key && Number.isFinite(numeric) && numeric >= 0) {
        acc[key.toLowerCase()] = numeric;
      }
      return acc;
    }, {});
  } catch {
    return {};
  }
};

export const extractInstanceTypeFromNodes = (nodes?: string): string | null => {
  if (!nodes) return null;

  const firstToken = nodes
    .split(/[,\s]+/)
    .map((token) => token.trim())
    .find((token) => token.length > 0);

  if (!firstToken) return null;

  const withoutIndex = firstToken.replace(/-\d+$/, "");
  return withoutIndex || firstToken;
};

const resolveInstanceRate = (instanceType: string | null): number | null => {
  if (!instanceType) return null;

  const rates = parseInstanceRates();
  if (Object.keys(rates).length === 0) return null;

  const normalized = instanceType.toLowerCase();
  if (typeof rates[normalized] === "number") return rates[normalized];

  const partial = Object.entries(rates).find(([key]) => normalized.includes(key) || key.includes(normalized));
  return partial ? partial[1] : null;
};

const resolveElapsedSeconds = (input: ExecutionCostInput): number => {
  if (typeof input.startTime === "number" && input.startTime > 0) {
    const effectiveEnd = typeof input.endTime === "number" && input.endTime > 0
      ? input.endTime
      : Math.floor(Date.now() / 1000);
    return Math.max(0, effectiveEnd - input.startTime);
  }

  return Math.max(0, input.elapsedSeconds);
};

export function calculateExecutionCost(input: ExecutionCostInput): ExecutionCostBreakdown {
  const elapsedSeconds = resolveElapsedSeconds(input);
  const elapsedHours = elapsedSeconds / 3600;
  const instanceType = extractInstanceTypeFromNodes(input.nodes);
  const instanceHourlyRate = resolveInstanceRate(instanceType);

  if (typeof instanceHourlyRate === "number") {
    return {
      cpuCost: 0,
      gpuCost: 0,
      totalCost: elapsedHours * instanceHourlyRate,
      elapsedHours,
      instanceType,
      instanceHourlyRate,
    };
  }

  const cpuRate = asPositiveNumber(
    input.cpuCostPerCoreHour,
    Number(process.env.JOB_CPU_COST_PER_CORE_HOUR ?? process.env.NEXT_PUBLIC_JOB_CPU_COST_PER_CORE_HOUR ?? 0.02)
  );
  const gpuRate = asPositiveNumber(
    input.gpuCostPerHour,
    Number(process.env.JOB_GPU_COST_PER_HOUR ?? process.env.NEXT_PUBLIC_JOB_GPU_COST_PER_HOUR ?? 0.5)
  );

  const cpuCount = Math.max(0, input.allocatedCpus ?? 0);
  const gpuCount = Math.max(0, input.gpuCount ?? 0);

  const cpuCost = cpuCount * elapsedHours * cpuRate;
  const gpuCost = gpuCount * elapsedHours * gpuRate;

  return {
    cpuCost,
    gpuCost,
    totalCost: cpuCost + gpuCost,
    elapsedHours,
    instanceType,
    instanceHourlyRate,
  };
}
