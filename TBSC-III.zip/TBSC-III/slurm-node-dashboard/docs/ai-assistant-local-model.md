# AI Assist with a Local Small Model

AI Assist uses an OpenAI-compatible API, so it can run against Ollama without changing the chat or Slurm tools.

## Ollama setup

Install Ollama, then pull a small model with tool-calling support:

```bash
ollama pull qwen2.5:3b
```

Set these server-side environment variables:

```env
OPENAI_API_KEY=ollama
OPENAI_API_URL=http://localhost:11434/v1
OPENAI_API_MODEL=qwen2.5:3b
OPENAI_API_MODEL_SUGGESTION=qwen2.5:3b
```

When the dashboard runs in Docker, `localhost` points to the dashboard container. Use `http://host.docker.internal:11434/v1` for Ollama on the host, or `http://ollama:11434/v1` when Ollama is another Compose service.

The model should be tested with the configured tools before production use. A 3B model is useful for concise Slurm guidance, but a larger tool-capable model may be more reliable for multi-step troubleshooting and complex `sbatch` requests.