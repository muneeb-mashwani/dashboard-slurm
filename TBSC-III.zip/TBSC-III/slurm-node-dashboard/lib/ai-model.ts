import { createOpenAI } from "@ai-sdk/openai";

const env = process.env;

const openAICompatible = createOpenAI({
  baseURL: env.OPENAI_API_URL,
  apiKey: env.OPENAI_API_KEY || "local-model",
});

export function getChatModel() {
  return openAICompatible.chat(env.OPENAI_API_MODEL || "gpt-4o-mini");
}

export function getSuggestionModel() {
  return openAICompatible.chat(
    env.OPENAI_API_MODEL_SUGGESTION ||
      env.OPENAI_API_MODEL ||
      "gpt-3.5-turbo"
  );
}