import { createOpenAI } from "@ai-sdk/openai";
import { extractReasoningMiddleware, wrapLanguageModel } from "ai";

const env = process.env;

const openAICompatible = createOpenAI({
  baseURL: env.OPENAI_API_URL,
  apiKey: env.OPENAI_API_KEY || "local-model",
});

// Qwen3.5 emits raw <think>...</think> reasoning blocks in its text output.
// Extract them instead of letting them leak into the visible chat response.
function withReasoningExtracted(model: Parameters<typeof wrapLanguageModel>[0]["model"]) {
  return wrapLanguageModel({
    model,
    middleware: extractReasoningMiddleware({ tagName: "think" }),
  });
}

export function getChatModel() {
  return withReasoningExtracted(
    openAICompatible.chat(env.OPENAI_API_MODEL || "gpt-4o-mini")
  );
}

export function getSuggestionModel() {
  return withReasoningExtracted(
    openAICompatible.chat(
      env.OPENAI_API_MODEL_SUGGESTION ||
        env.OPENAI_API_MODEL ||
        "gpt-3.5-turbo"
    )
  );
}