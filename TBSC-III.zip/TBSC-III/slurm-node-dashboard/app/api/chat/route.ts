import { streamText, convertToModelMessages, stepCountIs } from "ai";
import { loadLLMConfig, buildToolsAndPrompt } from "@/lib/llm-config";
import { getChatModel } from "@/lib/ai-model";

export const maxDuration = 30;

// Cap history sent to the model so token usage stays bounded on long conversations
const MAX_HISTORY_MESSAGES = 20;

export async function POST(req: Request) {
  const { messages } = await req.json();
  const trimmedMessages = messages.slice(-MAX_HISTORY_MESSAGES);

  // Build tools and system prompt dynamically from the YAML config
  const config = await loadLLMConfig();
  const { tools, systemPrompt } = buildToolsAndPrompt(config);

  const result = await streamText({
    model: getChatModel(),
    messages: await convertToModelMessages(trimmedMessages),
    system: systemPrompt,
    tools,
    stopWhen: stepCountIs(8),
  });

  return result.toUIMessageStreamResponse();
}
