import { streamText, convertToModelMessages, stepCountIs } from "ai";
import { loadLLMConfig, buildToolsAndPrompt } from "@/lib/llm-config";
import { getChatModel } from "@/lib/ai-model";

export const maxDuration = 30;

// Cap history sent to the model so token usage stays bounded on long conversations
const MAX_HISTORY_MESSAGES = 20;

// The local model unreliably routes "write me a job" requests straight to
// sbatch_helper on its own, instead manually enumerating partitions with other
// tools until it runs out of steps. Detect this intent and force-restrict the
// tool set so it has no choice but to call sbatch_helper.
const BATCH_JOB_ACTION_WORDS = /\b(write|create|help|generate)\b/i;
const BATCH_JOB_SUBJECT_WORDS = /\b(batch\s*job|sbatch|slurm\s*job|job\s*script)\b/i;

function getLastUserText(messages: any[]): string {
  const lastUser = [...messages].reverse().find((m) => m.role === "user");
  if (!lastUser?.parts) return "";
  return lastUser.parts
    .filter((p: any) => p.type === "text")
    .map((p: any) => p.text)
    .join(" ");
}

export async function POST(req: Request) {
  const { messages } = await req.json();
  const trimmedMessages = messages.slice(-MAX_HISTORY_MESSAGES);

  // Build tools and system prompt dynamically from the YAML config
  const config = await loadLLMConfig();
  const { tools, systemPrompt } = buildToolsAndPrompt(config);

  const lastUserText = getLastUserText(trimmedMessages);
  const isBatchJobRequest =
    BATCH_JOB_ACTION_WORDS.test(lastUserText) &&
    BATCH_JOB_SUBJECT_WORDS.test(lastUserText);
  const activeTools =
    isBatchJobRequest && tools.sbatch_helper
      ? { sbatch_helper: tools.sbatch_helper }
      : tools;

  // sbatch_helper gathers all cluster/partition/QoS data in a single call, so
  // when it's the only tool available there is never a reason to call it more
  // than once — cap the steps to prevent the model looping on repeat calls.
  const maxSteps = isBatchJobRequest ? 2 : 8;

  const result = await streamText({
    model: getChatModel(),
    messages: await convertToModelMessages(trimmedMessages),
    system: systemPrompt,
    tools: activeTools,
    stopWhen: stepCountIs(maxSteps),
  });

  return result.toUIMessageStreamResponse();
}
