"use client";

import { Bot } from "lucide-react";
import { useState } from "react";
import ChatModal from "../modals/chat-modal";
import { cn } from "@/lib/utils";

export default function ChatIcon() {
  const [showChat, setShowChat] = useState(false);

  function toggleChat() {
    setShowChat(!showChat);
  }

  return (
    <div>
      <button
        className={cn(
          "fixed bottom-[4.5rem] right-6 z-50 group",
          "flex h-12 items-center gap-2 rounded-full px-4",
          "bg-background/80 backdrop-blur-md border shadow-sm",
          "text-muted-foreground",
          "transition-all duration-300 ease-in-out",
          "hover:bg-primary hover:text-primary-foreground hover:shadow-md hover:scale-105",
          showChat && "bg-primary text-primary-foreground shadow-md ring-2 ring-primary/20"
        )}
        onClick={toggleChat}
        aria-label="Open AI Assist"
        title="AI Assist"
      >
        <Bot className="h-5 w-5" />
        <span className="text-sm font-medium">AI Assist</span>
      </button>
      <ChatModal showChat={showChat} setShowChat={setShowChat} />
    </div>
  );
}
