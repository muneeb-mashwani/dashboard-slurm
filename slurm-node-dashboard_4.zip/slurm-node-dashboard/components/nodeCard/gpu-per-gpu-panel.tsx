"use client";

import useSWR from "swr";
import { Line, LineChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "#f97316",
  "#14b8a6",
  "#a855f7",
];

interface GpuSeriesStats {
  gpu: string;
  label: string;
  mean: number;
  last: number;
  max: number;
}

interface HistoryResponse {
  status: number;
  data?: Record<string, string | number>[];
  series?: GpuSeriesStats[];
  message?: string;
}

interface GpuPerGpuPanelProps {
  nodeName: string;
  hours: number;
}

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export function GpuPerGpuPanel({ nodeName, hours }: GpuPerGpuPanelProps) {
  const { data: historyData, isLoading } = useSWR<HistoryResponse>(
    nodeName ? `/api/gpu/node/history?name=${encodeURIComponent(nodeName)}&hours=${hours}` : null,
    fetcher,
    { refreshInterval: 60000 }
  );

  const chartData = historyData?.data || [];
  const series = historyData?.series || [];

  const chartConfig = series.reduce((config, s, index) => {
    config[`gpu${s.gpu}`] = {
      label: s.label,
      color: COLORS[index % COLORS.length],
    };
    return config;
  }, {} as ChartConfig);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-4 w-60" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[200px] w-full" />
        </CardContent>
      </Card>
    );
  }

  if (chartData.length === 0 || series.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-medium">GPU Utilization (Per GPU)</CardTitle>
          <CardDescription>Per-GPU utilization over time</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-[200px] text-muted-foreground text-center px-4">
          {historyData?.message || "No GPU utilization data available for this node"}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">GPU Utilization (Per GPU)</CardTitle>
        <CardDescription>Per-GPU utilization over time</CardDescription>
      </CardHeader>
      <CardContent className="flex gap-4">
        <div className="flex-1 min-w-0">
          <ChartContainer config={chartConfig} className="h-[180px] w-full">
            <LineChart accessibilityLayer data={chartData} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis
                dataKey="time"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                tickFormatter={(value) =>
                  new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                }
                interval="preserveStartEnd"
                minTickGap={50}
              />
              <YAxis tickLine={false} axisLine={false} tickMargin={8} width={45} domain={[0, 100]} />
              <ChartTooltip
                content={<ChartTooltipContent indicator="dot" />}
                labelFormatter={(value) => new Date(value).toLocaleString()}
              />
              {series.map((s, index) => (
                <Line
                  key={s.gpu}
                  dataKey={`gpu${s.gpu}`}
                  type="monotone"
                  stroke={COLORS[index % COLORS.length]}
                  strokeWidth={1.5}
                  dot={false}
                  name={s.label}
                />
              ))}
            </LineChart>
          </ChartContainer>
        </div>
        <div className="w-[240px] shrink-0 overflow-y-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead className="text-right">Mean</TableHead>
                <TableHead className="text-right">Last</TableHead>
                <TableHead className="text-right">Max</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {series.map((s, index) => (
                <TableRow key={s.gpu}>
                  <TableCell className="flex items-center gap-2">
                    <span
                      className="inline-block h-2.5 w-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    {s.label}
                  </TableCell>
                  <TableCell className="text-right">{s.mean}%</TableCell>
                  <TableCell className="text-right">{s.last}%</TableCell>
                  <TableCell className="text-right">{s.max}%</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
