export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { fetchSlurmData } from "@/lib/slurm-api";
import { calculateExecutionCost } from "@/lib/job-cost";

interface NumericField {
  number?: number;
}

interface SlurmTresEntry {
  type?: string;
  name?: string;
  count?: number;
}

interface JobRecord {
  job_id?: string | number;
  user?: string;
  user_name?: string;
  flags?: string[];
  comment?: string;
  nodes?: string;
  command?: string;
  submit_line?: string;
  job_state?: string | string[];
  state?: { current?: string[]; reason?: string };
  cpus_per_task?: NumericField;
  cpus?: NumericField;
  required?: {
    CPUs?: number;
    memory_per_node?: NumericField;
  };
  memory_per_node?: NumericField;
  gres_detail?: string[];
  tres_req_str?: string;
  standard_output?: string;
  standard_error?: string;
  standard_input?: string;
  time_limit?: NumericField;
  priority?: NumericField;
  time?: {
    start?: number;
    end?: number;
    elapsed?: number;
    limit?: { number?: number };
  };
  start_time?: NumericField;
  end_time?: NumericField;
  tres?: {
    allocated?: SlurmTresEntry[];
    requested?: SlurmTresEntry[];
  };
}

const extractInstanceTypeFromComment = (comment?: unknown): string | null => {
  if (typeof comment !== "string") return null;

  const normalizedComment = comment.trim();
  if (!normalizedComment) return null;

  const entry = normalizedComment
    .split(",")
    .map((part) => part.trim())
    .find((part) => part.toLowerCase().startsWith("ec2instancetype="));

  if (!entry) return null;

  const value = entry.split("=").slice(1).join("=").trim();
  return value ? value.toLowerCase() : null;
};

const toNumber = (value: unknown, fallback = 0): number => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  return fallback;
};

const parseGpuCountFromText = (text?: string): number => {
  if (!text) return 0;
  const matches = text.match(/gpu(?::[^:,]+)?:(\d+)/gi);
  if (!matches) return 0;

  return matches.reduce((sum, token) => {
    const parts = token.split(":");
    const count = Number(parts.at(-1));
    return sum + (Number.isFinite(count) ? count : 0);
  }, 0);
};

const extractState = (job: JobRecord): string[] => {
  if (Array.isArray(job.job_state)) return job.job_state;
  if (typeof job.job_state === "string") return [job.job_state];
  if (job.state?.current?.length) return job.state.current;
  return ["UNKNOWN"];
};

const getElapsedSeconds = (job: JobRecord): number => {
  if (typeof job.time?.elapsed === "number") return Math.max(0, job.time.elapsed);

  const start = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
  const end = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));
  if (!start) return 0;

  const effectiveEnd = end > 0 ? end : Math.floor(Date.now() / 1000);
  return Math.max(0, effectiveEnd - start);
};

const getCpus = (job: JobRecord): number => {
  const fromTres = job.tres?.allocated?.find((entry) => entry.type?.toLowerCase() === "cpu")?.count;
  if (typeof fromTres === "number") return Math.max(0, fromTres);

  return Math.max(
    0,
    toNumber(job.required?.CPUs, 0) || toNumber(job.cpus_per_task?.number, 0) || toNumber(job.cpus?.number, 0)
  );
};

const getGpuCount = (job: JobRecord): number => {
  const tresGpu = (job.tres?.allocated || [])
    .filter((entry) => entry.type?.toLowerCase() === "gres" && entry.name?.toLowerCase().includes("gpu"))
    .reduce((sum, entry) => sum + toNumber(entry.count, 0), 0);

  if (tresGpu > 0) return tresGpu;

  const detail = Array.isArray(job.gres_detail) ? job.gres_detail.join(",") : "";
  const detailGpu = parseGpuCountFromText(detail);
  if (detailGpu > 0) return detailGpu;

  return parseGpuCountFromText(job.tres_req_str);
};

const toGb = (memoryValue: number): number => {
  if (memoryValue <= 0) return 0;
  return memoryValue / 1024;
};

const buildJobKey = (jobId: string, userName: string, startTime: number, state: string): string =>
  [jobId, userName, startTime, state].join("::");

const normalizeJobDetails = (job: JobRecord) => {
  const state = extractState(job);
  const primaryState = state[0] || "UNKNOWN";
  const elapsedSeconds = getElapsedSeconds(job);
  const allocatedCpus = getCpus(job);
  const gpuCount = getGpuCount(job);
  const startTime = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));
  const endTime = toNumber(job.time?.end, toNumber(job.end_time?.number, 0));

  const memoryPerNode = toNumber(job.memory_per_node?.number, toNumber(job.required?.memory_per_node?.number, 0));
  const timeLimitMinutes = toNumber(job.time_limit?.number, toNumber(job.time?.limit?.number, 0));
  const priority = toNumber(job.priority?.number, 0);
  const instanceTypeFromComment = extractInstanceTypeFromComment(job.comment);

  const cost = calculateExecutionCost({
    elapsedSeconds,
    allocatedCpus,
    gpuCount,
    nodes: job.nodes,
    instanceTypeOverride: instanceTypeFromComment ?? undefined,
    startTime,
    endTime,
  });

  const requestedGres = (job.tres?.requested || [])
    .filter((entry) => entry.type?.toLowerCase() === "gres")
    .map((entry) => `${entry.name || "gres"}:${toNumber(entry.count, 0)}`);

  return {
    jobId: String(job.job_id ?? ""),
    userName: job.user_name || job.user || "unknown",
    jobKey: buildJobKey(String(job.job_id ?? ""), job.user_name || job.user || "unknown", startTime, primaryState),
    nodes: job.nodes || "-",
    command: job.command || job.submit_line || "-",
    state,
    cpusPerTask: toNumber(job.cpus_per_task?.number, 0),
    allocatedCpus,
    memoryPerNodeGb: toGb(memoryPerNode),
    gresDetail: Array.isArray(job.gres_detail) && job.gres_detail.length > 0 ? job.gres_detail : requestedGres,
    outputPath: job.standard_output || "-",
    errorPath: job.standard_error || "-",
    inputPath: job.standard_input || "/dev/null",
    timeLimitMins: timeLimitMinutes,
    priority,
    elapsedSeconds,
    executionCost: cost.totalCost,
    startTime,
    endTime,
    instanceType: cost.instanceType,
    instanceHourlyRate: cost.instanceHourlyRate,
    flags: Array.isArray(job.flags)
      ? job.flags.filter((flag): flag is string => typeof flag === "string" && flag.trim().length > 0)
      : [],
  };
};

const matchJobRecord = (job: JobRecord, requestedJobKey: string | null, requestedUserName: string | null, requestedStartTime: number | null) => {
  const state = extractState(job);
  const primaryState = state[0] || "UNKNOWN";
  const jobId = String(job.job_id ?? "");
  const userName = job.user_name || job.user || "unknown";
  const startTime = toNumber(job.time?.start, toNumber(job.start_time?.number, 0));

  if (requestedJobKey) {
    return buildJobKey(jobId, userName, startTime, primaryState) === requestedJobKey;
  }

  if (requestedUserName && userName !== requestedUserName) {
    return false;
  }

  if (requestedStartTime !== null && startTime !== requestedStartTime) {
    return false;
  }

  return true;
};

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string[] }> }
) {
  const url = new URL(req.url);
  const { id } = await params;
  const jobId = id[0];
  const requestedJobKey = url.searchParams.get("jobKey");
  const requestedUserName = url.searchParams.get("userName");
  const requestedStartTimeRaw = url.searchParams.get("startTime");
  const requestedStartTime = requestedStartTimeRaw ? Number(requestedStartTimeRaw) : null;

  const completedResponse = await fetchSlurmData(`/job/${jobId}`, {
    type: "slurmdb",
    revalidate: 0,
  });
  const completedJobs = Array.isArray(completedResponse.data?.jobs)
    ? (completedResponse.data.jobs as JobRecord[])
    : [];

  if (!completedResponse.error && completedJobs.length > 0) {
    const matchedJob = completedJobs.find((job) =>
      matchJobRecord(job, requestedJobKey, requestedUserName, Number.isFinite(requestedStartTime) ? requestedStartTime : null)
    ) || completedJobs[0];

    return NextResponse.json({
      source: "completed",
      job: normalizeJobDetails(matchedJob),
    });
  }

  const status = completedResponse.status || 404;
  return NextResponse.json({ error: "Job not found" }, { status });
}
