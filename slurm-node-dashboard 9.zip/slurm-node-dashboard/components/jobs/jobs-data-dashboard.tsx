"use client";

import { ChangeEvent, useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
} from "@/components/ui/pagination";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search } from "lucide-react";

interface JobRow {
  jobKey: string;
  jobId: string;
  userName: string;
  name: string;
  state: string;
  partition: string;
  nodes: string;
  startTime: number;
  endTime: number;
  elapsedSeconds: number;
  allocatedCpus: number;
  gpuCount: number;
  executionCost: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

interface JobDetails {
  jobKey: string;
  jobId: string;
  userName: string;
  flags: string[];
  nodes: string;
  command: string;
  state: string[];
  cpusPerTask: number;
  allocatedCpus: number;
  memoryPerNodeGb: number;
  gresDetail: string[];
  outputPath: string;
  errorPath: string;
  inputPath: string;
  timeLimitMins: number;
  priority: number;
  executionCost: number;
  startTime: number;
  endTime: number;
  instanceType: string | null;
  instanceHourlyRate: number | null;
}

interface JobsDataResponse {
  jobs: JobRow[];
}

interface JobDetailsResponse {
  source: "active" | "completed";
  job: JobDetails;
}

const jsonFetcher = (url: string) => fetch(url).then((res) => res.json());
const ITEMS_PER_PAGE = 20;

const formatDuration = (seconds: number): string => {
  if (seconds <= 0) return "-";
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours}h ${minutes}m`;
};

const formatTimestamp = (unixSeconds: number): string => {
  if (!unixSeconds || unixSeconds <= 0) return "-";
  return new Date(unixSeconds * 1000).toLocaleString();
};

const formatCurrency = (value: number): string => `$${value.toFixed(2)}`;

const stateBadgeVariant = (state: string): "default" | "secondary" | "destructive" => {
  if (state === "FAILED" || state === "TIMEOUT" || state.startsWith("CANCELLED")) return "destructive";
  return "secondary";
};

const buildDetailsUrl = (job: JobRow | null): string | null => {
  if (!job) return null;

  const params = new URLSearchParams({
    jobKey: job.jobKey,
    userName: job.userName,
    startTime: String(job.startTime),
  });

  return `/api/slurm/job/details/${job.jobId}?${params.toString()}`;
};

const getVisiblePageNumbers = (currentPage: number, totalPages: number): Array<number | "ellipsis-start" | "ellipsis-end"> => {
  if (totalPages <= 7) {
    return Array.from({ length: totalPages }, (_, index) => index + 1);
  }

  if (currentPage <= 4) {
    return [1, 2, 3, 4, 5, "ellipsis-end", totalPages];
  }

  if (currentPage >= totalPages - 3) {
    return [1, "ellipsis-start", totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
  }

  return [1, "ellipsis-start", currentPage - 1, currentPage, currentPage + 1, "ellipsis-end", totalPages];
};

export default function JobsDataDashboard() {
  const [jobIdSearch, setJobIdSearch] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedJob, setSelectedJob] = useState<JobRow | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { data, isLoading, error } = useSWR<JobsDataResponse>("/api/slurm/jobs/executed?limit=10000&lookbackDays=365", jsonFetcher, {
    refreshInterval: 60000,
  });

  const { data: detailsData, isLoading: detailsLoading } = useSWR<JobDetailsResponse>(
    isModalOpen ? buildDetailsUrl(selectedJob) : null,
    jsonFetcher
  );

  const filteredJobs = useMemo(() => {
    const allJobs = data?.jobs || [];
    const normalizedJobId = jobIdSearch.trim().toLowerCase();
    const normalizedUser = userSearch.trim().toLowerCase();

    return allJobs.filter((job: JobRow) => {
      const jobIdMatches = normalizedJobId ? job.jobId.toLowerCase().includes(normalizedJobId) : true;
      const userMatches = normalizedUser ? job.userName.toLowerCase().includes(normalizedUser) : true;
      return jobIdMatches && userMatches;
    });
  }, [data?.jobs, jobIdSearch, userSearch]);

  useEffect(() => {
    setCurrentPage(1);
  }, [jobIdSearch, userSearch]);

  const totalPages = Math.max(1, Math.ceil(filteredJobs.length / ITEMS_PER_PAGE));
  const safeCurrentPage = Math.min(currentPage, totalPages);

  useEffect(() => {
    if (currentPage !== safeCurrentPage) {
      setCurrentPage(safeCurrentPage);
    }
  }, [currentPage, safeCurrentPage]);

  const paginatedJobs = useMemo(() => {
    const startIndex = (safeCurrentPage - 1) * ITEMS_PER_PAGE;
    return filteredJobs.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredJobs, safeCurrentPage]);

  const selectedJobDetails = detailsData?.job;

  const openJobModal = (job: JobRow) => {
    setSelectedJob(job);
    setIsModalOpen(true);
  };

  const closeJobModal = (open: boolean) => {
    setIsModalOpen(open);
    if (!open) {
      setSelectedJob(null);
    }
  };

  const pageNumbers = getVisiblePageNumbers(safeCurrentPage, totalPages);

  return (
    <>
      <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Jobs Data</CardTitle>
          <CardDescription>
            Browse executed jobs and inspect detailed execution metadata with estimated cost.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={jobIdSearch}
                onChange={(event: ChangeEvent<HTMLInputElement>) => setJobIdSearch(event.target.value)}
                placeholder="Search by job ID"
                className="pl-9"
              />
            </div>
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={userSearch}
                onChange={(event: ChangeEvent<HTMLInputElement>) => setUserSearch(event.target.value)}
                placeholder="Search by username"
                className="pl-9"
              />
            </div>
          </div>

          {error && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
              Failed to load jobs data from Slurm.
            </div>
          )}

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job ID</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>State</TableHead>
                  <TableHead>Partition</TableHead>
                  <TableHead>Instance</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && (
                  <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                      Loading jobs...
                    </TableCell>
                  </TableRow>
                )}

                {!isLoading && filteredJobs.length === 0 && (
                  <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                      No jobs found for the current filters.
                    </TableCell>
                  </TableRow>
                )}

                {!isLoading &&
                  paginatedJobs.map((job: JobRow) => (
                    <TableRow
                      key={job.jobKey}
                      onClick={() => {
                        openJobModal(job);
                      }}
                      className="cursor-pointer"
                      data-state={selectedJob?.jobKey === job.jobKey ? "selected" : undefined}
                    >
                      <TableCell className="font-mono">{job.jobId}</TableCell>
                      <TableCell>{job.userName}</TableCell>
                      <TableCell>
                        <Badge variant={stateBadgeVariant(job.state)}>{job.state}</Badge>
                      </TableCell>
                      <TableCell>{job.partition}</TableCell>
                      <TableCell className="font-mono">{job.instanceType || "-"}</TableCell>
                      <TableCell>{formatTimestamp(job.startTime)}</TableCell>
                      <TableCell>{formatDuration(job.elapsedSeconds)}</TableCell>
                      <TableCell className="font-medium">{formatCurrency(job.executionCost)}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>

            {!isLoading && filteredJobs.length > 0 && (
              <div className="flex flex-col gap-3 pt-2 md:flex-row md:items-center md:justify-between">
                <p className="text-sm text-muted-foreground">
                  Showing {(safeCurrentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(safeCurrentPage * ITEMS_PER_PAGE, filteredJobs.length)} of {filteredJobs.length} jobs
                </p>
                <Pagination className="mx-0 w-auto justify-start md:justify-end">
                  <PaginationContent>
                    <PaginationItem>
                      <Button
                        variant="outline"
                        size="sm"
                        type="button"
                        onClick={() => setCurrentPage((page: number) => Math.max(1, page - 1))}
                        disabled={safeCurrentPage === 1}
                      >
                        Prev
                      </Button>
                    </PaginationItem>

                    {pageNumbers.map((pageNumber) => {
                      if (pageNumber === "ellipsis-start" || pageNumber === "ellipsis-end") {
                        return (
                          <PaginationItem key={pageNumber}>
                            <PaginationEllipsis />
                          </PaginationItem>
                        );
                      }

                      return (
                        <PaginationItem key={pageNumber}>
                          <Button
                            type="button"
                            variant={pageNumber === safeCurrentPage ? "secondary" : "ghost"}
                            size="sm"
                            onClick={() => setCurrentPage(pageNumber)}
                          >
                            {pageNumber}
                          </Button>
                        </PaginationItem>
                      );
                    })}

                    <PaginationItem>
                      <Button
                        variant="outline"
                        size="sm"
                        type="button"
                        onClick={() => setCurrentPage((page: number) => Math.min(totalPages, page + 1))}
                        disabled={safeCurrentPage === totalPages}
                      >
                        Next
                      </Button>
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
        </CardContent>
      </Card>
        </div>

        <Dialog open={isModalOpen} onOpenChange={closeJobModal}>
          <DialogContent aria-describedby={undefined} className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <span>Job Details</span>
                {selectedJob && <span className="font-mono text-base">{selectedJob.jobId}</span>}
              </DialogTitle>
              <DialogDescription>
                Terminal job metadata and cost breakdown for the selected job record.
              </DialogDescription>
            </DialogHeader>

            {selectedJob && detailsLoading && (
              <p className="text-sm text-muted-foreground">Loading job details...</p>
            )}

            {selectedJob && !detailsLoading && !selectedJobDetails && (
              <p className="text-sm text-destructive">Unable to load the selected job details.</p>
            )}

            {selectedJob && !detailsLoading && selectedJobDetails && (
              <div className="grid grid-cols-1 gap-3 text-sm md:grid-cols-2">
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Job ID</div>
                  <div className="font-mono font-medium">{selectedJobDetails.jobId}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">User</div>
                  <div className="font-medium">{selectedJobDetails.userName}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Nodes</div>
                  <div className="font-medium">{selectedJobDetails.nodes || "-"}</div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Instance Type</div>
                  <div className="font-mono">{selectedJobDetails.instanceType || "-"}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Instance Hourly Rate</div>
                  <div className="font-medium">
                    {typeof selectedJobDetails.instanceHourlyRate === "number"
                      ? formatCurrency(selectedJobDetails.instanceHourlyRate)
                      : "Not configured"}
                  </div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Start Time</div>
                  <div className="font-medium">{formatTimestamp(selectedJobDetails.startTime)}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">End Time</div>
                  <div className="font-medium">{formatTimestamp(selectedJobDetails.endTime)}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Command</div>
                  <div className="font-mono break-all">{selectedJobDetails.command || "-"}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">State</div>
                  <div className="font-medium">{selectedJobDetails.state.join(", ")}</div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">CPUs Per Task</div>
                  <div className="font-medium">{selectedJobDetails.cpusPerTask || selectedJobDetails.allocatedCpus || "-"}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Memory per Node (GB)</div>
                  <div className="font-medium">{selectedJobDetails.memoryPerNodeGb ? selectedJobDetails.memoryPerNodeGb.toFixed(2) : "-"}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Gres Detail</div>
                  <div className="font-medium">{selectedJobDetails.gresDetail?.length ? selectedJobDetails.gresDetail.join(", ") : "-"}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Output Path</div>
                  <div className="font-mono break-all">{selectedJobDetails.outputPath || "-"}</div>
                </div>
                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Error Path</div>
                  <div className="font-mono break-all">{selectedJobDetails.errorPath || "-"}</div>
                </div>
                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Input Path</div>
                  <div className="font-mono break-all">{selectedJobDetails.inputPath || "-"}</div>
                </div>

                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Time Limit (mins)</div>
                  <div className="font-medium">{selectedJobDetails.timeLimitMins || "-"}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="text-muted-foreground">Priority</div>
                  <div className="font-medium">{selectedJobDetails.priority || "-"}</div>
                </div>

                <div className="rounded-md border bg-muted/40 p-3 md:col-span-2">
                  <div className="text-muted-foreground">Cost of execution</div>
                  <div className="text-lg font-semibold">{formatCurrency(selectedJobDetails.executionCost || 0)}</div>
                </div>

                <div className="rounded-md border p-3 md:col-span-2">
                  <div className="text-muted-foreground">Flags Used</div>
                  <div className="font-medium break-words">
                    {selectedJobDetails.flags?.length ? selectedJobDetails.flags.join(", ") : "-"}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </>
  );
}
