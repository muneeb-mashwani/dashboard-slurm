"use client"

import * as React from "react"
import useSWR from "swr"
import { Line, LineChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Skeleton } from "@/components/ui/skeleton"
import { gpuUtilizationPluginMetadata } from "@/actions/plugins"

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "#f97316",
  "#14b8a6",
  "#a855f7",
]

const RANGE_OPTIONS = [
  { label: "Last 6 hours", hours: 6 },
  { label: "Last 12 hours", hours: 12 },
  { label: "Last 24 hours", hours: 24 },
  { label: "Last 3 days", hours: 72 },
  { label: "Last 7 days", hours: 168 },
]

interface NodesResponse {
  status: number
  nodes?: string[]
}

interface GpuSeriesStats {
  gpu: string
  label: string
  modelName: string
  mean: number
  last: number
  max: number
}

interface HistoryResponse {
  status: number
  data?: Record<string, string | number>[]
  series?: GpuSeriesStats[]
  message?: string
}

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export function GpuNodeUtilizationChart() {
  const [selectedNode, setSelectedNode] = React.useState<string>("")
  const [hours, setHours] = React.useState(24)

  const { data: nodesData } = useSWR<NodesResponse>(
    gpuUtilizationPluginMetadata.isEnabled ? "/api/gpu/nodes" : null,
    fetcher
  )
  const nodes = nodesData?.nodes || []

  React.useEffect(() => {
    if (nodes.length > 0 && !selectedNode) {
      setSelectedNode(nodes[0])
    }
  }, [nodes, selectedNode])

  const { data: historyData, isLoading } = useSWR<HistoryResponse>(
    gpuUtilizationPluginMetadata.isEnabled && selectedNode
      ? `/api/gpu/node/history?name=${encodeURIComponent(selectedNode)}&hours=${hours}`
      : null,
    fetcher,
    { refreshInterval: 60000 }
  )

  if (!gpuUtilizationPluginMetadata.isEnabled) return null

  const chartData = historyData?.data || []
  const series = historyData?.series || []

  const chartConfig = series.reduce((config, s, index) => {
    config[`gpu${s.gpu}`] = {
      label: s.label,
      color: COLORS[index % COLORS.length],
    }
    return config
  }, {} as ChartConfig)

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle>GPU Utilization</CardTitle>
          <CardDescription>
            Per-GPU utilization over time for the selected node
          </CardDescription>
        </div>
        <div className="flex gap-2 items-start">
          {nodes.length > 0 && (
            <Tabs value={selectedNode} onValueChange={setSelectedNode}>
              <TabsList>
                {nodes.map((node) => (
                  <TabsTrigger key={node} value={node}>
                    {node}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          )}
          <Select value={String(hours)} onValueChange={(v) => setHours(parseFloat(v))}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Time range" />
            </SelectTrigger>
            <SelectContent>
              {RANGE_OPTIONS.map((opt) => (
                <SelectItem key={opt.hours} value={String(opt.hours)}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 flex gap-4">
        <div className="flex-1 min-w-0">
          {isLoading ? (
            <Skeleton className="h-full w-full" />
          ) : chartData.length === 0 || series.length === 0 ? (
            <div className="flex items-center justify-center h-48 text-muted-foreground text-center px-4">
              {historyData?.message || "No GPU utilization data available for this node"}
            </div>
          ) : (
            <ChartContainer config={chartConfig} className="h-full w-full">
              <LineChart accessibilityLayer data={chartData} margin={{ left: 12, right: 12 }}>
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="time"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tickFormatter={(value) =>
                    new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                  }
                />
                <YAxis tickLine={false} axisLine={false} tickMargin={8} domain={[0, 100]} />
                <ChartTooltip
                  content={<ChartTooltipContent indicator="dot" />}
                  labelFormatter={(value) => new Date(value).toLocaleString()}
                />
                {series.map((s, index) => (
                  <Line
                    key={s.gpu}
                    dataKey={`gpu${s.gpu}`}
                    type="monotone"
                    stroke={COLORS[index % COLORS.length]}
                    strokeWidth={1.5}
                    dot={false}
                    name={s.label}
                  />
                ))}
              </LineChart>
            </ChartContainer>
          )}
        </div>
        {series.length > 0 && (
          <div className="w-[280px] shrink-0 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead className="text-right">Mean</TableHead>
                  <TableHead className="text-right">Last</TableHead>
                  <TableHead className="text-right">Max</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {series.map((s, index) => (
                  <TableRow key={s.gpu}>
                    <TableCell className="flex items-center gap-2">
                      <span
                        className="inline-block h-2.5 w-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      />
                      {s.label}
                    </TableCell>
                    <TableCell className="text-right">{s.mean}%</TableCell>
                    <TableCell className="text-right">{s.last}%</TableCell>
                    <TableCell className="text-right">{s.max}%</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
