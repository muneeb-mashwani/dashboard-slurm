"use client"

import * as React from "react"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Cell } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface GpuNodeData {
    name: string;
    value: number;
    jobCount: number;
}

interface GpuNodeChartProps {
    data: GpuNodeData[];
}

const COLORS = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
];

export function GpuNodeChart({ data }: GpuNodeChartProps) {
    const nodeNames = data?.map((d) => d.name) || []
    const [selectedNode, setSelectedNode] = React.useState(nodeNames[0])

    React.useEffect(() => {
        if (nodeNames.length > 0 && !nodeNames.includes(selectedNode)) {
            setSelectedNode(nodeNames[0])
        }
    }, [nodeNames, selectedNode])

    const chartConfig = {
        value: {
            label: "GPU Hours",
            color: "hsl(var(--chart-3))",
        },
    } satisfies ChartConfig

    if (!data || data.length === 0) {
        return (
            <Card className="h-full">
                <CardHeader>
                    <CardTitle>GPU Hours by Node</CardTitle>
                    <CardDescription>
                        GPU usage distribution across the busiest nodes
                    </CardDescription>
                </CardHeader>
                <CardContent className="flex items-center justify-center h-48 text-muted-foreground">
                    No GPU node data available
                </CardContent>
            </Card>
        )
    }

    return (
        <Card className="h-full">
            <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div>
                    <CardTitle>GPU Hours by Node</CardTitle>
                    <CardDescription>
                        GPU usage distribution across the busiest nodes
                    </CardDescription>
                </div>
                <Select value={selectedNode} onValueChange={setSelectedNode}>
                    <SelectTrigger className="w-[220px]">
                        <SelectValue placeholder="Select a node" />
                    </SelectTrigger>
                    <SelectContent>
                        {nodeNames.map((node) => (
                            <SelectItem key={node} value={node}>
                                {node}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </CardHeader>
            <CardContent className="flex-1 min-h-0">
                <ChartContainer config={chartConfig} className="h-full w-full">
                    <BarChart accessibilityLayer data={data} layout="vertical">
                        <CartesianGrid horizontal={false} />
                        <XAxis type="number" />
                        <YAxis
                            dataKey="name"
                            type="category"
                            tickLine={false}
                            axisLine={false}
                            width={100}
                        />
                        <ChartTooltip
                            content={<ChartTooltipContent />}
                            formatter={(value: any, name: any, props: any) => [
                                `${value.toLocaleString()} GPU Hours (${props.payload.jobCount} jobs)`,
                                name
                            ]}
                        />
                        <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                            {data.map((entry, index) => (
                                <Cell
                                    key={`cell-${index}`}
                                    fill={entry.name === selectedNode ? COLORS[0] : COLORS[(index + 1) % COLORS.length]}
                                    fillOpacity={entry.name === selectedNode ? 1 : 0.5}
                                />
                            ))}
                        </Bar>
                    </BarChart>
                </ChartContainer>
            </CardContent>
        </Card>
    )
}
