"use client"

import * as React from "react"
import { Line, LineChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface GpuNodeTimeSeriesChartProps {
  data: any[];
  nodes: string[];
}

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
]

export function GpuNodeTimeSeriesChart({ data, nodes }: GpuNodeTimeSeriesChartProps) {
  const [selectedNode, setSelectedNode] = React.useState(nodes[0])

  React.useEffect(() => {
    if (nodes.length > 0 && !nodes.includes(selectedNode)) {
      setSelectedNode(nodes[0])
    }
  }, [nodes, selectedNode])

  const chartConfig = {
    [selectedNode]: {
      label: selectedNode,
      color: COLORS[0],
    },
  } satisfies ChartConfig

  if (!data || data.length === 0 || nodes.length === 0) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>GPU Usage by Node</CardTitle>
          <CardDescription>
            GPU hours consumed over time for the busiest GPU nodes
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-48 text-muted-foreground">
          No GPU node data available for the selected period
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle>GPU Usage by Node</CardTitle>
          <CardDescription>
            GPU hours consumed over time for the selected node
          </CardDescription>
        </div>
        <Select value={selectedNode} onValueChange={setSelectedNode}>
          <SelectTrigger className="w-[220px]">
            <SelectValue placeholder="Select a node" />
          </SelectTrigger>
          <SelectContent>
            {nodes.map((node) => (
              <SelectItem key={node} value={node}>
                {node}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="flex-1 min-h-0">
        <ChartContainer config={chartConfig} className="h-full w-full">
          <LineChart accessibilityLayer data={data} margin={{ left: 12, right: 12 }}>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="date"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              tickFormatter={(value) => value.slice(5)}
            />
            <YAxis tickLine={false} axisLine={false} tickMargin={8} />
            <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
            <Line
              dataKey={selectedNode}
              type="monotone"
              stroke={COLORS[0]}
              strokeWidth={2}
              dot={false}
              name={selectedNode}
            />
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
