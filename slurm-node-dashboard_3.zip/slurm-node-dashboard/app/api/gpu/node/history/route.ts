export const dynamic = 'force-dynamic';

import { NextResponse } from "next/server";
import { prom } from "@/lib/prometheus";
import { buildGpuMetricsFilter, extractNumericValue, promSelector } from "@/lib/gpu-metrics";
import type { PrometheusSampleValue } from "@/lib/gpu-metrics";

const escapePromString = (value: string) =>
  value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');

interface RangeSample {
  time: number | string;
  value: PrometheusSampleValue;
}

interface RangeSeriesItem {
  metric?: { labels?: Record<string, string | undefined> };
  values?: RangeSample[];
}

interface RangeQueryResult {
  result?: RangeSeriesItem[];
}

// Cap the number of points per series so the chart stays responsive.
const MAX_POINTS = 300;

function getStepSeconds(hours: number): number {
  const totalSeconds = hours * 3600;
  return Math.max(60, Math.ceil(totalSeconds / MAX_POINTS / 60) * 60);
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const node = url.searchParams.get("name");
  const hoursParam = parseFloat(url.searchParams.get("hours") || "24");
  const hours = isNaN(hoursParam) || hoursParam <= 0 ? 24 : Math.min(hoursParam, 168);

  if (!node) {
    return NextResponse.json({ status: 400, message: "Missing required 'name' parameter" });
  }

  if (!prom) {
    return NextResponse.json({ status: 404, message: "Prometheus connection not configured" });
  }

  const end = new Date();
  const start = new Date(end.getTime() - hours * 60 * 60 * 1000);
  const step = getStepSeconds(hours);

  try {
    const filter = buildGpuMetricsFilter([`Hostname="${escapePromString(node)}"`]);
    const query = promSelector("DCGM_FI_DEV_GPU_UTIL", filter);
    const result = (await prom.rangeQuery(query, start, end, step)) as unknown as RangeQueryResult;

    if (!result?.result || result.result.length === 0) {
      return NextResponse.json({
        status: 404,
        message: "No GPU utilization data found for the specified node.",
      });
    }

    const series = result.result
      .map((item) => {
        const labels = item.metric?.labels || {};
        const gpuIndex = labels.gpu || "unknown";
        const values = (item.values || []).map((sample) => {
          const time = typeof sample.time === "number" ? sample.time : parseFloat(String(sample.time));
          const value = extractNumericValue(sample.value);
          return { time, value: isNaN(value) ? 0 : value };
        });

        const nums = values.map((v) => v.value);
        const mean = nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
        const max = nums.length ? Math.max(...nums) : 0;
        const last = nums.length ? nums[nums.length - 1] : 0;

        return {
          gpu: gpuIndex,
          label: `GPU ${gpuIndex}`,
          modelName: labels.modelName || "unknown",
          values,
          mean: Math.round(mean * 10) / 10,
          last: Math.round(last * 10) / 10,
          max: Math.round(max * 10) / 10,
        };
      })
      .sort((a, b) => parseInt(a.gpu, 10) - parseInt(b.gpu, 10));

    // Merge into a single array of { time, gpu0, gpu1, ... } for charting
    const timeSet = new Set<number>();
    series.forEach((s) => s.values.forEach((v) => timeSet.add(v.time)));
    const times = Array.from(timeSet).sort((a, b) => a - b);

    const chartData = times.map((time) => {
      const entry: Record<string, number | string> = {
        time: new Date(time * 1000).toISOString(),
      };
      series.forEach((s) => {
        const match = s.values.find((v) => v.time === time);
        entry[`gpu${s.gpu}`] = match ? match.value : 0;
      });
      return entry;
    });

    return NextResponse.json({
      status: 200,
      node,
      hours,
      data: chartData,
      series: series.map(({ gpu, label, modelName, mean, last, max }) => ({
        gpu,
        label,
        modelName,
        mean,
        last,
        max,
      })),
    });
  } catch (error) {
    console.error("Error fetching GPU node history:", error);
    return NextResponse.json({
      status: 500,
      message: "Error fetching GPU node history",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
}
