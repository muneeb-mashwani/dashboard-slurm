export const dynamic = 'force-dynamic';

import { NextResponse } from "next/server";
import { prom } from "@/lib/prometheus";
import { buildGpuMetricsFilter, promSelector } from "@/lib/gpu-metrics";

interface SeriesItem {
  metric?: { labels?: Record<string, string | undefined> };
}

interface InstantResult {
  result?: SeriesItem[];
}

// Returns only nodes that actually have DCGM/GPU metrics in Prometheus,
// rather than every node in the cluster's node.cfg (most of which have no GPUs).
export async function GET() {
  if (!prom) {
    return NextResponse.json({ status: 404, message: "Prometheus connection not configured" });
  }

  try {
    const filter = buildGpuMetricsFilter();
    const query = `count by (Hostname) (${promSelector("DCGM_FI_DEV_GPU_UTIL", filter)})`;
    const result = (await prom.instantQuery(query)) as unknown as InstantResult;

    const nodes = Array.from(
      new Set(
        (result?.result || [])
          .map((item) => item.metric?.labels?.Hostname)
          .filter((hostname): hostname is string => Boolean(hostname))
      )
    ).sort();

    return NextResponse.json({ status: 200, nodes });
  } catch (error) {
    return NextResponse.json({
      status: 500,
      message: "Error loading GPU node list",
      error: error instanceof Error ? error.message : String(error),
    });
  }
}
