export const dynamic = 'force-dynamic';

import { NextResponse } from "next/server";
import { getConfiguredNodeNames } from "@/lib/node-config";

export async function GET() {
  try {
    const nodes = await getConfiguredNodeNames();
    return NextResponse.json({ status: 200, nodes });
  } catch (error) {
    return NextResponse.json({
      status: 500,
      message: "Error loading node list",
      error: error instanceof Error ? error.message : String(error),
    });
  }
}
